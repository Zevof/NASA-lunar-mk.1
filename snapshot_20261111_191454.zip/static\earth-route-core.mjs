// Earth-to-Moon transfer survey: Earth-centred two-body Lambert approximations.
// These solutions are NOT launch/landing trajectories, mission opportunities,
// or a precision Earth-Moon n-body targeting service.
import {RAD,dot,mag,mul,add,sub,unit,clamp,normal} from './nav-core.mjs';
export const EARTH_RADIUS_KM=6378.137;
export const EARTH_MU_KM3_S2=398600.4418;
export const MOON_RADIUS_KM=1737.4;
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
function julian(date){return date.getTime()/86400000+2440587.5;}
export function gmstRadians(utc){
 const jd=julian(new Date(utc)),T=(jd-2451545)/36525;
 const deg=(280.46061837+360.98564736629*(jd-2451545)+.000387933*T*T-T*T*T/38710000)%360;
 return ((deg%360+360)%360)*RAD;
}
export function earthSiteDirectionECI(utc,lat,lon){
 const theta=gmstRadians(utc)+lon*RAD,latr=lat*RAD;
 return [Math.cos(latr)*Math.cos(theta),Math.cos(latr)*Math.sin(theta),Math.sin(latr)];
}
const moonPoleECI=unit([Math.cos(269.995*RAD)*Math.cos(66.539*RAD),Math.sin(269.995*RAD)*Math.cos(66.539*RAD),Math.sin(66.539*RAD)]);
export function moonFrame(earthFixed,moonECI){
 // Approximate axes mapping using Earth's Moon-fixed direction and mean lunar pole.
 // Earth position is constrained exactly; precise IAU lunar orientation needs SPICE.
 const efix=unit(earthFixed),eeci=mul(unit(moonECI),-1);
 const xeci=unit(cross(moonPoleECI,eeci)),yeci=cross(eeci,xeci);
 const xfixed=unit(cross([0,0,1],efix)),yfixed=cross(efix,xfixed);
 return {
   toFixed:vec=>add(add(mul(efix,dot(vec,eeci)),mul(xfixed,dot(vec,xeci))),mul(yfixed,dot(vec,yeci))),
   toECI:vec=>add(add(mul(eeci,dot(vec,efix)),mul(xeci,dot(vec,xfixed))),mul(yeci,dot(vec,yfixed)))
 };
}
function stumpff(z){
 if(Math.abs(z)<1e-6)return {C:.5-z/24+z*z/720,S:1/6-z/120+z*z/5040};
 if(z>0){let q=Math.sqrt(z);return {C:(1-Math.cos(q))/z,S:(q-Math.sin(q))/(q*q*q)};}
 let q=Math.sqrt(-z);if(q>150)throw Error('Stumpff argument outside numerical range');
 return {C:(Math.cosh(q)-1)/(-z),S:(Math.sinh(q)-q)/(q*q*q)};
}
export function lambertShortWay(r1,r2,tofSeconds,mu=EARTH_MU_KM3_S2){
 if(!(tofSeconds>0)||!Number.isFinite(tofSeconds))throw Error('Transfer time must be positive.');
 const m1=mag(r1),m2=mag(r2),costheta=clamp(dot(r1,r2)/(m1*m2),-1,1),sintheta=Math.sqrt(Math.max(0,1-costheta*costheta));
 const A=sintheta*Math.sqrt(m1*m2/(1-costheta));
 if(!Number.isFinite(A)||A<1e-5)throw Error('Nearly collinear transfer geometry; change departure epoch.');
 const flight=z=>{
  const {C,S}=stumpff(z);if(C<=0)return null;
  const y=m1+m2+A*(z*S-1)/Math.sqrt(C);if(y<=0)return null;
  return {t:((y/C)**1.5*S+A*Math.sqrt(y))/Math.sqrt(mu),y};
 };
 let low=null,high=null;
 for(let i=0;i<=300;i++){
  const z=-80+i*(80+4*Math.PI*Math.PI-1e-5)/300;
  const value=flight(z);if(!value||!Number.isFinite(value.t))continue;
  if(value.t<=tofSeconds)low={z,...value};
  if(value.t>tofSeconds){high={z,...value};break;}
 }
 if(!low||!high)throw Error('Transfer has no short-way Lambert solution for this time and geometry.');
 let z=0,res;
 for(let i=0;i<95;i++){
  z=(low.z+high.z)/2;res=flight(z);if(!res){low.z=z;continue;}
  if(res.t>tofSeconds)high={z,...res};else low={z,...res};
 }
 res=flight(z);
 const f=1-res.y/m1,g=A*Math.sqrt(res.y/mu),gdot=1-res.y/m2;
 if(Math.abs(g)<1e-9)throw Error('Singular Lambert geometry.');
 const v1=mul(sub(r2,mul(r1,f)),1/g),v2=mul(sub(mul(r2,gdot),r1),1/g);
 return {v1,v2,departureKm:r1,arrivalKm:r2,transferSeconds:tofSeconds};
}
export function propagateTwoBody(r0,v0,seconds,mu=EARTH_MU_KM3_S2){
 if(seconds===0)return [...r0];
 const rmag=mag(r0),v2=dot(v0,v0),rv=dot(r0,v0),alpha=2/rmag-v2/mu;
 let x=Math.sqrt(mu)*Math.max(Math.abs(alpha),.000001)*seconds;
 if(Math.abs(alpha)<1e-7)x=Math.sqrt(mu)*seconds/rmag;
 // Newton with damping; long-transfer convergence checked against Lambert endpoint.
 for(let i=0;i<110;i++){
  const z=alpha*x*x,{C,S}=stumpff(z);
  const F=rv/Math.sqrt(mu)*x*x*C+(1-alpha*rmag)*x*x*x*S+rmag*x-Math.sqrt(mu)*seconds;
  const dF=rv/Math.sqrt(mu)*x*(1-z*S)+(1-alpha*rmag)*x*x*C+rmag;
  if(!Number.isFinite(dF)||Math.abs(dF)<1e-9)throw Error('Orbit propagation is singular.');
  let dx=F/dF;
  if(Math.abs(dx)>2e4)dx=Math.sign(dx)*2e4;
  x-=dx;if(Math.abs(dx)<1e-7)break;
  if(i===109)throw Error('Orbit propagation did not converge.');
 }
 const z=alpha*x*x,{C,S}=stumpff(z);
 const f=1-x*x*C/rmag,g=seconds-x*x*x*S/Math.sqrt(mu);
 return add(mul(r0,f),mul(v0,g));
}
export const MOON_MU_KM3_S2=4902.800066;
export const MOON_SOI_RADIUS_KM=66100;
const MOON_CAPTURE_ALTITUDE_KM=100;

function solve3x3(A,b){
 const a=A.map(row=>[...row]),x=Array(3).fill(0),rhs=[...b];
 for(let col=0;col<3;col++){
  let pivot=col;
  for(let row=col+1;row<3;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
  if(Math.abs(a[pivot][col])<1e-12)return null;
  if(pivot!==col){[a[pivot],a[col]]=[a[col],a[pivot]];[rhs[pivot],rhs[col]]=[rhs[col],rhs[pivot]];}
  for(let row=col+1;row<3;row++){
   const factor=a[row][col]/a[col][col];
   for(let k=col;k<3;k++)a[row][k]-=factor*a[col][k];
   rhs[row]-=factor*rhs[col];
  }
 }
 for(let row=2;row>=0;row--){
  let value=rhs[row];
  for(let k=row+1;k<3;k++)value-=a[row][k]*x[k];
  x[row]=value/a[row][row];
 }
 return x;
}

const moonStateCache=new Map();
function moonStateAt(frames,ms){
 const key=frames.length+'|'+Math.round(ms/1000);
 if(moonStateCache.has(key))return moonStateCache.get(key);
 const at=lerpFrame(frames,ms);
 if(!at)return null;
 const dt=60000,before=lerpFrame(frames,ms-dt),after=lerpFrame(frames,ms+dt);
 let velocity;
 if(before&&after)velocity=mul(sub(after.moon_eci_km,before.moon_eci_km),1/(2*dt));
 else if(after)velocity=mul(sub(after.moon_eci_km,at.moon_eci_km),1/dt);
 else if(before)velocity=mul(sub(at.moon_eci_km,before.moon_eci_km),1/dt);
 else velocity=Array(3).fill(0);
 const state={position:at.moon_eci_km,velocity};
 if(moonStateCache.size>50000)moonStateCache.clear();
 moonStateCache.set(key,state);
 return state;
}

function earthMoonAcceleration(r,moonState){
 const rmag=mag(r),d=sub(r,moonState.position),dmag=mag(d);
 if(rmag<1||dmag<1)throw Error('Spacecraft state is inside a celestial body.');
 return add(
  mul(r,-EARTH_MU_KM3_S2/(rmag*rmag*rmag)),
  mul(d,-MOON_MU_KM3_S2/(dmag*dmag*dmag))
 );
}

function earthMoonDerivative(ms,r,v,frames){
 const moon=moonStateAt(frames,ms);
 if(!moon)throw Error('Moon ephemerides do not cover the transfer interval.');
 return {dr:v,dv:earthMoonAcceleration(r,moon)};
}

export function propagateEarthMoon(r0,v0,startTimeMs,seconds,frames,options={}){
 if(!Array.isArray(r0)||r0.length!==3||!Array.isArray(v0)||v0.length!==3)throw Error('Initial state must be 3D vectors.');
 if(!(seconds>0)||!Number.isFinite(seconds))throw Error('Propagation time must be positive.');
 const maxStep=Math.max(1,Number(options.maxStepSeconds)||120);
 const steps=Math.max(1,Math.ceil(seconds/maxStep)),dt=seconds/steps;
 const sampleCount=Math.max(2,Number(options.sampleCount)||72);
 const sampleEvery=Math.max(1,Math.round(steps/(sampleCount-1)));
 let r=[...r0],v=[...v0],ms=startTimeMs;
 const samples=[r.slice()];
 for(let i=0;i<steps;i++){
  const k1=earthMoonDerivative(ms,r,v,frames);
  const k2=earthMoonDerivative(ms+dt*500,add(r,mul(k1.dr,dt/2)),add(v,mul(k1.dv,dt/2)),frames);
  const k3=earthMoonDerivative(ms+dt*500,add(r,mul(k2.dr,dt/2)),add(v,mul(k2.dv,dt/2)),frames);
  const k4=earthMoonDerivative(ms+dt*1000,add(r,mul(k3.dr,dt)),add(v,mul(k3.dv,dt)),frames);
  r=add(r,mul(add(add(k1.dr,mul(k2.dr,2)),add(mul(k3.dr,2),k4.dr)),dt/6));
  v=add(v,mul(add(add(k1.dv,mul(k2.dv,2)),add(mul(k3.dv,2),k4.dv)),dt/6));
  ms+=dt*1000;
  if((i+1)%sampleEvery===0||i===steps-1)samples.push(r.slice());
 }
 return {position:r,velocity:v,samples};
}

export function correctEarthMoonTrajectory(r1,v0Guess,target,startTimeMs,seconds,frames){
 const I0=0,I1=1,I2=2;
 let v=[...v0Guess],best=null,lambda=1e-3;
 const evaluate=vel=>{
  const propagated=propagateEarthMoon(r1,vel,startTimeMs,seconds,frames);
  const error=sub(propagated.position,target);
  return {propagated,error,errorMag:mag(error)};
 };
 for(let iteration=0;iteration<80;iteration++){
  const nominal=evaluate(v);
  if(!best||nominal.errorMag<best.errorMag)best={v:v.slice(),nominal:nominal.propagated,errorMag:nominal.errorMag};
  if(nominal.errorMag<.25)return {v,nominal:nominal.propagated,converged:true,iterations:iteration+1,errorKm:nominal.errorMag};
  const h=Math.max(1e-5,mag(v)*2e-5),jacobian=Array.from({length:3},()=>new Array(3).fill(0));
  for(let axis=0;axis<3;axis++){
   const plus=[...v];plus[axis]+=h;
   const minus=[...v];minus[axis]-=h;
   const a=evaluate(plus),b=evaluate(minus);
   const delta=sub(a.propagated.position,b.propagated.position);
   for(let row=0;row<3;row++)jacobian[row][axis]=delta[row]/(2*h);
  }
  const jtj=Array.from({length:3},()=>new Array(3).fill(0)),jte=new Array(3).fill(0);
  for(let i=0;i<3;i++){
   for(let j=0;j<3;j++){
    let value=0;
    for(let k=0;k<3;k++)value+=jacobian[k][i]*jacobian[k][j];
    jtj[i][j]=value;
   }
   let value=0;
   for(let k=0;k<3;k++)value+=jacobian[k][i]*nominal.error[k];
   jte[i]=-value;
  }
  let jtjScale=1e-12;
  for(let i=0;i<3;i++)jtjScale=Math.max(jtjScale,jtj[i][i]);
  let accepted=null;
  for(let attempt=0;attempt<12;attempt++){
   const damped=jtj.map((row,i)=>row.map((value,j)=>i===j?value+lambda*jtjScale:value));
   const correction=solve3x3(damped,jte);
   if(!correction)break;
   const trial=add(v,correction);
   const trialState=evaluate(trial);
   if(Number.isFinite(trialState.errorMag)&&trialState.errorMag<nominal.errorMag){
    accepted={trial,trialState};
    lambda=Math.max(1e-12,lambda*.5);
    break;
   }
   lambda*=5;
  }
  if(!accepted)break;
  v=accepted.trial;
 }
 if(!best)throw Error('Trajectory correction could not evaluate an initial guess.');
 if(best.errorMag<.25)return {v:best.v,nominal:best.nominal,converged:true,iterations:80,errorKm:best.errorMag};
 const vec3=(a,b,c)=>{const r=new Array(3);r[I0]=a;r[I1]=b;r[I2]=c;return r;};
 const cost=vec=>evaluate(vec).errorMag;
 let startV=best.v.slice(),startErr=best.errorMag;
 for(let si=0;si<3;si++){
  const scale=si===0?.01:(si===1?.05:.1);
  for(let axis=0;axis<3;axis++){
   for(let s2=0;s2<2;s2++){
    const sign=s2===0?1:-1;
    const trial=[...startV];trial[axis]+=sign*scale;
    const err=cost(trial);
    if(Number.isFinite(err)&&err<startErr){startErr=err;startV=trial;}
   }
  }
 }
 const step=.01;
 let vertices=[];
 vertices.push(startV.slice());
 vertices.push(vec3(startV[I0]+step,startV[I1],startV[I2]));
 vertices.push(vec3(startV[I0],startV[I1]+step,startV[I2]));
 vertices.push(vec3(startV[I0],startV[I1],startV[I2]+step));
 let values=vertices.map(cost);
 let bestV=startV.slice(),bestErr=startErr;
 for(let iter=0;iter<120;iter++){
  const order=vertices.map((vec,i)=>i).sort((a,b)=>values[a]-values[b]);
  vertices=order.map(i=>vertices[i]);
  values=order.map(i=>values[i]);
  if(values[I0]<bestErr){bestErr=values[I0];bestV=vertices[I0].slice();}
  if(bestErr<.25)break;
  const n=3;
  let centroid=new Array(3).fill(0);
  for(let i=0;i<n;i++)centroid=add(centroid,vertices[i]);
  centroid=mul(centroid,1/n);
  const worst=vertices[n];
  const reflect=add(centroid,sub(centroid,worst));
  const reflectVal=cost(reflect);
  if(values[I0]<=reflectVal&&reflectVal<values[n-1]){
   vertices[n]=reflect;values[n]=reflectVal;
  }else if(reflectVal<values[I0]){
   const expand=add(centroid,mul(sub(centroid,worst),2));
   const expandVal=cost(expand);
   if(expandVal<reflectVal){vertices[n]=expand;values[n]=expandVal;}
   else{vertices[n]=reflect;values[n]=reflectVal;}
  }else{
   const outside=reflectVal<values[n];
   const contract=outside?add(centroid,mul(sub(centroid,worst),.5)):add(centroid,mul(sub(vertices[I0],centroid),.5));
   const contractVal=cost(contract);
   const threshold=outside?reflectVal:values[I0];
   if(contractVal<threshold){vertices[n]=contract;values[n]=contractVal;}
   else{
    for(let i=1;i<=n;i++){
     vertices[i]=add(vertices[I0],mul(sub(vertices[i],vertices[I0]),.5));
     values[i]=cost(vertices[i]);
    }
   }
  }
 }
 const finalNominal=evaluate(bestV).propagated;
 return {v:bestV,nominal:finalNominal,converged:bestErr<.25,iterations:80,errorKm:bestErr};
}

export function lerpFrame(frames,ms){
 if(frames.length<2)return frames[0];
 const first=Date.parse(frames[0].utc),last=Date.parse(frames.at(-1).utc);
 if(ms<first||ms>last)return null;
 let lo=0,hi=frames.length-1;
 while(hi-lo>1){const mid=(hi+lo)>>1;if(Date.parse(frames[mid].utc)<=ms)lo=mid;else hi=mid;}
 const a=frames[lo],b=frames[hi],dt=Date.parse(b.utc)-Date.parse(a.utc),t=dt>0?(ms-Date.parse(a.utc))/dt:0;
 const field=k=>a[k].map((v,i)=>v*(1-t)+b[k][i]*t);
 return {utc:new Date(ms).toISOString(),moon_eci_km:field('moon_eci_km'),sun_eci_km:field('sun_eci_km'),earth_moon_fixed:unit(field('earth_moon_fixed')),sun_moon_fixed:unit(field('sun_moon_fixed'))};
}
export function surveyTransfers(frames,launchIndex,earthSite,moonSite,terrainHeightKm=0,options={}){
 const launch=frames[launchIndex];if(!launch)throw Error('Load a timeline to compute transfers.');
 const startTime=Date.parse(launch.utc);
 const parkingAlt=options.parkingAltKm??200;
 if(parkingAlt<160||parkingAlt>2000)throw Error('Parking orbit altitude must be 160–2000 km.');
 const eciStart=earthSiteDirectionECI(launch.utc,earthSite.lat,earthSite.lon);
 const r1=mul(eciStart,EARTH_RADIUS_KM+parkingAlt);
 const desiredNormal=normal(moonSite.lat,moonSite.lon);
 const durations=options.durationsHours??[72,84,96,108,120,132,144];
 const candidates=[];
 for(const hours of durations){
  const arrival=lerpFrame(frames,startTime+hours*3600000);if(!arrival)continue;
  try{
   const frame=moonFrame(arrival.earth_moon_fixed,arrival.moon_eci_km);
   const surfaceEci=frame.toECI(desiredNormal);
   const r2=[...arrival.moon_eci_km];
   let best=null;
 const initialGuess=lambertShortWay(r1,r2,hours*3600);
 const corrected=correctEarthMoonTrajectory(r1,initialGuess.v1,r2,startTime,hours*3600,frames);
 best={v:corrected.v,propagated:corrected.nominal,errorMag:corrected.errorKm};
   
   const trajectory={v1:best.v,v2:null,departureKm:r1,arrivalKm:r2,transferSeconds:hours*3600};
   const samples=best.propagated.samples;
   const finalState=best.propagated;
   const arrivalMoon=moonStateAt(frames,startTime+hours*3600000);
   const moonRelativeVelocity=sub(finalState.velocity,arrivalMoon.velocity);
   const moonRelativePosition=sub(r2,arrivalMoon.position);
   const lunarOrbitSpeed=Math.sqrt(MOON_MU_KM3_S2/mag(moonRelativePosition));
   const captureDeltaV=Math.max(0,mag(moonRelativeVelocity)-lunarOrbitSpeed);
   const miss=best.errorMag;
   const minRadius=Math.min(...samples.map(mag));
     if(miss>500)continue;
   if(minRadius<EARTH_RADIUS_KM+120)continue;
   const parkingSpeed=Math.sqrt(EARTH_MU_KM3_S2/mag(r1));
   // Approximate minimum velocity change from an optimally oriented circular parking orbit.
   const radial=dot(best.v,unit(r1));
   const tangentialMag=Math.sqrt(Math.max(0,dot(best.v,best.v)-radial*radial));
   const deltaV=Math.hypot(radial,tangentialMag-parkingSpeed);
   const localSun=dot(desiredNormal,unit(arrival.sun_moon_fixed));
   const localEarth=dot(desiredNormal,unit(arrival.earth_moon_fixed));
   const sunElevation=Math.asin(clamp(localSun,-1,1))/RAD;
   const earthElevation=Math.asin(clamp(localEarth,-1,1))/RAD;
   // Survey score is a user-facing heuristic only; not a trajectory optimizer.
   const score= -deltaV + (sunElevation>5?.25:0)+(earthElevation>10?.15:0) - Math.abs(hours-108)*.0008;
   candidates.push({hours,deltaVkmS:deltaV,captureDeltaVkmS:captureDeltaV,sunElevation,earthElevation,score,missKm:miss,approximate:miss>30,minRadiusKm:minRadius,
     arrivalUTC:arrival.utc,launchUTC:launch.utc,trajectory:{...trajectory,samples},arrivalFrame:arrival});
  }catch(error){ console.warn('transfer candidate failed',hours,error?.message??error,error?.stack?.split('\n').slice(0,5).join(' | ')); }
 }
 if(!candidates.length)throw Error('No valid preliminary transfer candidates: choose an earlier date, use a longer NASA timeline (at least 7 days), or change Earth/Moon coordinates.');
 return candidates.sort((a,b)=>b.score-a.score);
}
// Quick-look, non-JPL visualization for the time slider before ephemerides load.
export function previewFrames(startDate,days,stepHours){
 const start=new Date(startDate+'T00:00:00Z').getTime(),count=Math.min(1400,Math.floor(days*24/stepHours)+1);
 if(!Number.isFinite(start)||count<2)return [];
 const frames=[];
 for(let i=0;i<count;i++){
  const d=new Date(start+i*stepHours*3600000),jd=julian(d);
  const moonAngle=2*Math.PI*(jd-2451545)/27.321661;
  const moon=[384400*Math.cos(moonAngle),384400*Math.sin(moonAngle)*Math.cos(5.14*RAD),384400*Math.sin(moonAngle)*Math.sin(5.14*RAD)];
  const sunAngle=2*Math.PI*(jd-2451545)/365.25636;
  const sun=[149597870*Math.cos(sunAngle),149597870*Math.sin(sunAngle)*Math.cos(23.44*RAD),149597870*Math.sin(sunAngle)*Math.sin(23.44*RAD)];
  const eci=unit(mul(moon,-1)),side=unit(cross(moonPoleECI,eci)),up=cross(eci,side);
  const sd=unit(sub(sun,moon));
  const sunFixed=[dot(sd,eci),dot(sd,side),dot(sd,up)];
  frames.push({utc:d.toISOString(),jd,moon_eci_km:moon,sun_eci_km:sun,earth_moon_fixed:[1,0,0],sun_moon_fixed:sunFixed});
 }
 return frames;
}


// ---------------------------------------------------------------------------
// Earth city graph and geodesy
// ---------------------------------------------------------------------------

/**
 * Embedded GeoNames-derived city data and strategic launch-site nodes.
 * The data is embedded so the application works without a runtime fetch and
 * remains compatible with the self-contained Rust static-file server.
 */
const EARTH_CITY_DATA = {"cities":[{"id":"c001","name":"Shanghai","lat":31.22222,"lon":121.45806,"population":24874500,"country":"China"},{"id":"c002","name":"Chongqing","lat":29.56026,"lon":106.55771,"population":22000000,"country":"China"},{"id":"c003","name":"Chengdu","lat":30.66667,"lon":104.06667,"population":20937757,"country":"China"},{"id":"c004","name":"Beijing","lat":39.9075,"lon":116.39723,"population":18960744,"country":"China"},{"id":"c005","name":"Guangzhou","lat":23.11667,"lon":113.25,"population":18676605,"country":"China"},{"id":"c006","name":"Shenzhen","lat":22.54554,"lon":114.0683,"population":17494398,"country":"China"},{"id":"c007","name":"Kinshasa","lat":-4.32758,"lon":15.31357,"population":16000000,"country":"Congo - Kinshasa"},{"id":"c008","name":"Istanbul","lat":41.01384,"lon":28.94966,"population":15701602,"country":"Türkiye"},{"id":"c009","name":"Lagos","lat":6.45407,"lon":3.39467,"population":15388000,"country":"Nigeria"},{"id":"c010","name":"Ho Chi Minh City","lat":10.82302,"lon":106.62965,"population":14002598,"country":"Vietnam"},{"id":"c011","name":"Tianjin","lat":39.14222,"lon":117.17667,"population":13866009,"country":"China"},{"id":"c012","name":"Wuhan","lat":30.58333,"lon":114.26667,"population":13739000,"country":"China"},{"id":"c013","name":"Lahore","lat":31.558,"lon":74.35071,"population":13004135,"country":"Pakistan"},{"id":"c014","name":"Xi’an","lat":34.25833,"lon":108.92861,"population":12952907,"country":"China"},{"id":"c015","name":"Mumbai","lat":19.07283,"lon":72.88261,"population":12691836,"country":"India"},{"id":"c016","name":"São Paulo","lat":-23.5475,"lon":-46.63611,"population":12400232,"country":"Brazil"},{"id":"c017","name":"Mexico City","lat":19.42847,"lon":-99.12766,"population":12294193,"country":"Mexico"},{"id":"c018","name":"Hangzhou","lat":30.29365,"lon":120.16142,"population":11936010,"country":"China"},{"id":"c019","name":"Karachi","lat":24.8608,"lon":67.0104,"population":11624219,"country":"Pakistan"},{"id":"c020","name":"Delhi","lat":28.65195,"lon":77.23149,"population":11034555,"country":"India"},{"id":"c021","name":"Moscow","lat":55.75204,"lon":37.61781,"population":10381222,"country":"Russia"},{"id":"c022","name":"Dhaka","lat":23.7104,"lon":90.40744,"population":10356500,"country":"Bangladesh"},{"id":"c023","name":"Seoul","lat":37.566,"lon":126.9784,"population":10349312,"country":"South Korea"},{"id":"c024","name":"Harbin","lat":45.75,"lon":126.65,"population":10009854,"country":"China"},{"id":"c025","name":"Tokyo","lat":35.6895,"lon":139.69171,"population":9733276,"country":"Japan"},{"id":"c026","name":"Dongguan","lat":23.01797,"lon":113.74866,"population":9644871,"country":"China"},{"id":"c027","name":"Cairo","lat":30.06263,"lon":31.24967,"population":9606916,"country":"Egypt"},{"id":"c028","name":"Hefei","lat":31.86389,"lon":117.28083,"population":9465881,"country":"China"},{"id":"c029","name":"Johannesburg","lat":-26.20227,"lon":28.04363,"population":9418183,"country":"South Africa"},{"id":"c030","name":"Weifang","lat":36.71,"lon":119.10194,"population":9386705,"country":"China"},{"id":"c031","name":"Nanjing","lat":32.06167,"lon":118.77778,"population":9314685,"country":"China"},{"id":"c032","name":"Shenyang","lat":41.79222,"lon":123.43278,"population":9070093,"country":"China"},{"id":"c033","name":"Foshan","lat":23.02677,"lon":113.13148,"population":9042509,"country":"China"},{"id":"c034","name":"London","lat":51.50853,"lon":-0.12574,"population":8961989,"country":"United Kingdom"},{"id":"c035","name":"New York City","lat":40.71427,"lon":-74.00597,"population":8804190,"country":"United States"},{"id":"c036","name":"Jakarta","lat":-6.21462,"lon":106.84513,"population":8540121,"country":"Indonesia"},{"id":"c037","name":"Bengaluru","lat":12.97194,"lon":77.59369,"population":8495492,"country":"India"},{"id":"c038","name":"Jinan","lat":36.66833,"lon":116.99722,"population":8352574,"country":"China"},{"id":"c039","name":"Hanoi","lat":21.0245,"lon":105.84117,"population":8053663,"country":"Vietnam"},{"id":"c040","name":"Taipei","lat":25.05306,"lon":121.52639,"population":7871900,"country":"Taiwan"},{"id":"c041","name":"Lima","lat":-12.04318,"lon":-77.02824,"population":7737002,"country":"Peru"},{"id":"c042","name":"Bogotá","lat":4.60971,"lon":-74.08175,"population":7674366,"country":"Colombia"},{"id":"c043","name":"Dalian","lat":38.91222,"lon":121.60222,"population":7450785,"country":"China"},{"id":"c044","name":"Hong Kong","lat":22.27832,"lon":114.17469,"population":7396076,"country":"Hong Kong SAR China"},{"id":"c045","name":"Baghdad","lat":33.34058,"lon":44.40088,"population":7216000,"country":"Iraq"},{"id":"c046","name":"Wuzhong","lat":37.9867,"lon":106.201,"population":7202654,"country":"China"},{"id":"c047","name":"Qingdao","lat":36.06488,"lon":120.38042,"population":7172451,"country":"China"},{"id":"c048","name":"Tehran","lat":35.69439,"lon":51.42151,"population":7153309,"country":"Iran"},{"id":"c049","name":"Yantai","lat":37.47649,"lon":121.44081,"population":7102100,"country":"China"},{"id":"c050","name":"Hyderabad","lat":17.38405,"lon":78.45636,"population":6993262,"country":"India"},{"id":"c051","name":"Rio de Janeiro","lat":-22.90642,"lon":-43.18223,"population":6747815,"country":"Brazil"},{"id":"c052","name":"Suzhou","lat":31.30408,"lon":120.59538,"population":6715559,"country":"China"},{"id":"c053","name":"Puxi","lat":31.24414,"lon":121.46592,"population":6683712,"country":"China"},{"id":"c054","name":"Zhengzhou","lat":34.75778,"lon":113.64861,"population":6650532,"country":"China"},{"id":"c055","name":"Ahmedabad","lat":23.02579,"lon":72.58727,"population":6357693,"country":"India"},{"id":"c056","name":"Abidjan","lat":5.35444,"lon":-4.00167,"population":6321017,"country":"Côte d’Ivoire"},{"id":"c057","name":"Nanning","lat":22.81667,"lon":108.31667,"population":5977185,"country":"China"},{"id":"c058","name":"Kunming","lat":25.03889,"lon":102.71833,"population":5950578,"country":"China"},{"id":"c059","name":"Shijiazhuang","lat":38.04139,"lon":114.47861,"population":5758403,"country":"China"},{"id":"c060","name":"Changchun","lat":43.88,"lon":125.32278,"population":5691024,"country":"China"},{"id":"c061","name":"Pudong","lat":31.23995,"lon":121.50094,"population":5681512,"country":"China"},{"id":"c062","name":"Sydney","lat":-33.86785,"lon":151.20732,"population":5638830,"country":"Australia"},{"id":"c063","name":"Singapore","lat":1.28967,"lon":103.85007,"population":5638700,"country":"Singapore"},{"id":"c064","name":"Melbourne","lat":-37.814,"lon":144.96332,"population":5435590,"country":"Australia"},{"id":"c065","name":"Dar es Salaam","lat":-6.82349,"lon":39.26951,"population":5383728,"country":"Tanzania"},{"id":"c066","name":"Saint Petersburg","lat":59.93863,"lon":30.31413,"population":5351935,"country":"Russia"},{"id":"c067","name":"Taiyuan","lat":37.86944,"lon":112.56028,"population":5305061,"country":"China"},{"id":"c068","name":"Alexandria","lat":31.20176,"lon":29.91582,"population":5263542,"country":"Egypt"},{"id":"c069","name":"Bangkok","lat":13.75398,"lon":100.50144,"population":5104476,"country":"Thailand"},{"id":"c070","name":"Kano","lat":12.00012,"lon":8.51672,"population":4910000,"country":"Nigeria"},{"id":"c071","name":"Santiago","lat":-33.45694,"lon":-70.64827,"population":4837295,"country":"Chile"},{"id":"c072","name":"Cape Town","lat":-33.92584,"lon":18.42322,"population":4772846,"country":"South Africa"},{"id":"c073","name":"Peshawar","lat":34.008,"lon":71.57849,"population":4758762,"country":"Pakistan"},{"id":"c074","name":"Zibo","lat":36.79056,"lon":118.06333,"population":4704138,"country":"China"},{"id":"c075","name":"Jeddah","lat":21.49012,"lon":39.18624,"population":4697000,"country":"Saudi Arabia"},{"id":"c076","name":"Chennai","lat":13.08784,"lon":80.27847,"population":4681087,"country":"India"},{"id":"c077","name":"Kolkata","lat":22.56263,"lon":88.36304,"population":4631392,"country":"India"},{"id":"c078","name":"Xiamen","lat":24.47979,"lon":118.08187,"population":4617251,"country":"China"},{"id":"c079","name":"Surat","lat":21.19594,"lon":72.83023,"population":4591246,"country":"India"},{"id":"c080","name":"Yangzhou","lat":32.39722,"lon":119.43583,"population":4559797,"country":"China"},{"id":"c081","name":"Huai'an","lat":33.58861,"lon":119.01917,"population":4556230,"country":"China"},{"id":"c082","name":"Guiyang","lat":26.58333,"lon":106.71667,"population":4506134,"country":"China"},{"id":"c083","name":"Yangon","lat":16.80528,"lon":96.15611,"population":4477638,"country":"Myanmar (Burma)"},{"id":"c084","name":"Bao'an","lat":22.55213,"lon":113.88288,"population":4476554,"country":"China"},{"id":"c085","name":"Kabul","lat":34.52813,"lon":69.17233,"population":4434550,"country":"Afghanistan"},{"id":"c086","name":"Nairobi","lat":-1.28333,"lon":36.81667,"population":4397073,"country":"Kenya"},{"id":"c087","name":"Wuxi","lat":31.56887,"lon":120.28857,"population":4396835,"country":"China"},{"id":"c088","name":"Giza","lat":30.00944,"lon":31.20861,"population":4367343,"country":"Egypt"},{"id":"c089","name":"Lanzhou","lat":36.05701,"lon":103.83987,"population":4359446,"country":"China"},{"id":"c090","name":"Bamako","lat":12.60915,"lon":-7.97522,"population":4227569,"country":"Mali"},{"id":"c091","name":"Riyadh","lat":24.68773,"lon":46.72185,"population":4205961,"country":"Saudi Arabia"},{"id":"c092","name":"Fuzhou","lat":26.06139,"lon":119.30611,"population":4094491,"country":"China"},{"id":"c093","name":"Ürümqi","lat":43.80096,"lon":87.60046,"population":4054000,"country":"China"},{"id":"c094","name":"New Taipei City","lat":25.06199,"lon":121.45703,"population":4004367,"country":"Taiwan"},{"id":"c095","name":"New Territories","lat":22.42441,"lon":114.11095,"population":3984077,"country":"Hong Kong SAR China"},{"id":"c096","name":"Chattogram","lat":22.3384,"lon":91.83168,"population":3920222,"country":"Bangladesh"},{"id":"c097","name":"Addis Ababa","lat":9.02497,"lon":38.74689,"population":3860000,"country":"Ethiopia"},{"id":"c098","name":"Zaozhuang","lat":34.86472,"lon":117.55417,"population":3855601,"country":"China"},{"id":"c099","name":"Zhongshan","lat":22.52306,"lon":113.37912,"population":3841873,"country":"China"},{"id":"c100","name":"Shantou","lat":23.35489,"lon":116.67876,"population":3838900,"country":"China"},{"id":"c101","name":"Los Angeles","lat":34.05223,"lon":-118.24368,"population":3820914,"country":"United States"},{"id":"c102","name":"Faisalabad","lat":31.41554,"lon":73.08969,"population":3800193,"country":"Pakistan"},{"id":"c103","name":"Dubai","lat":25.07725,"lon":55.30927,"population":3790000,"country":"United Arab Emirates"},{"id":"c104","name":"Yokohama","lat":35.43333,"lon":139.65,"population":3777491,"country":"Japan"},{"id":"c105","name":"Ningbo","lat":29.87819,"lon":121.54945,"population":3731203,"country":"China"},{"id":"c106","name":"Nanhai","lat":23.02193,"lon":113.14278,"population":3667247,"country":"China"},{"id":"c107","name":"Casablanca","lat":33.58831,"lon":-7.61138,"population":3665954,"country":"Morocco"},{"id":"c108","name":"Ibadan","lat":7.37756,"lon":3.90591,"population":3649000,"country":"Nigeria"},{"id":"c109","name":"Puyang","lat":29.45679,"lon":119.88872,"population":3590000,"country":"China"},{"id":"c110","name":"Ankara","lat":39.91987,"lon":32.85427,"population":3517182,"country":"Türkiye"},{"id":"c111","name":"Shiyan","lat":32.6475,"lon":110.77806,"population":3460000,"country":"China"},{"id":"c112","name":"Hohhot","lat":40.81056,"lon":111.65222,"population":3446100,"country":"China"},{"id":"c113","name":"Berlin","lat":52.52437,"lon":13.41053,"population":3426354,"country":"Germany"},{"id":"c114","name":"Tangshan","lat":39.64381,"lon":118.18319,"population":3372102,"country":"China"},{"id":"c115","name":"Rawalpindi","lat":33.59733,"lon":73.0479,"population":3357612,"country":"Pakistan"},{"id":"c116","name":"Lüliang","lat":37.5192,"lon":111.14436,"population":3346500,"country":"China"},{"id":"c117","name":"Durban","lat":-29.8579,"lon":31.0292,"population":3338026,"country":"South Africa"},{"id":"c118","name":"Anshan","lat":41.12361,"lon":122.99,"population":3325372,"country":"China"},{"id":"c119","name":"Changzhou","lat":31.77359,"lon":119.95401,"population":3290918,"country":"China"},{"id":"c120","name":"Busan","lat":35.10168,"lon":129.03004,"population":3285147,"country":"South Korea"},{"id":"c121","name":"Madrid","lat":40.4165,"lon":-3.70256,"population":3255944,"country":"Spain"},{"id":"c122","name":"Pyongyang","lat":39.03385,"lon":125.75432,"population":3222000,"country":"North Korea"},{"id":"c123","name":"Pune","lat":18.51957,"lon":73.85535,"population":3124458,"country":"India"},{"id":"c124","name":"Datong","lat":40.09361,"lon":113.29139,"population":3105591,"country":"China"},{"id":"c125","name":"Bursa","lat":40.19559,"lon":29.06013,"population":3101833,"country":"Türkiye"},{"id":"c126","name":"Changsha","lat":28.19874,"lon":112.97087,"population":3093980,"country":"China"},{"id":"c127","name":"Quezon City","lat":14.6488,"lon":121.0509,"population":3084270,"country":"Philippines"},{"id":"c128","name":"Jaipur","lat":26.91962,"lon":75.78781,"population":3046163,"country":"India"},{"id":"c129","name":"Huainan","lat":32.62639,"lon":116.99694,"population":3033528,"country":"China"},{"id":"c130","name":"Surabaya","lat":-7.24917,"lon":112.75083,"population":3018022,"country":"Indonesia"},{"id":"c131","name":"Incheon","lat":37.45646,"lon":126.70515,"population":3015482,"country":"South Korea"},{"id":"c132","name":"Haikou","lat":20.03421,"lon":110.34651,"population":3001600,"country":"China"},{"id":"c133","name":"Caracas","lat":10.48801,"lon":-66.87919,"population":3000000,"country":"Venezuela"},{"id":"c134","name":"Kyiv","lat":50.45466,"lon":30.5238,"population":2952301,"country":"Ukraine"},{"id":"c135","name":"İzmir","lat":38.41273,"lon":27.13838,"population":2938292,"country":"Türkiye"},{"id":"c136","name":"Huizhou","lat":23.11147,"lon":114.41523,"population":2900113,"country":"China"},{"id":"c137","name":"Buenos Aires","lat":-34.61315,"lon":-58.37723,"population":2891082,"country":"Argentina"},{"id":"c138","name":"Yinchuan","lat":38.46806,"lon":106.27306,"population":2859074,"country":"China"},{"id":"c139","name":"Taichung","lat":24.1469,"lon":120.6839,"population":2850285,"country":"Taiwan"},{"id":"c140","name":"Kanpur","lat":26.46523,"lon":80.34975,"population":2823249,"country":"India"},{"id":"c141","name":"Toronto","lat":43.65333,"lon":-79.38389,"population":2794356,"country":"Canada"},{"id":"c142","name":"Quito","lat":-0.22985,"lon":-78.52495,"population":2781641,"country":"Ecuador"},{"id":"c143","name":"Brisbane","lat":-27.46794,"lon":153.02809,"population":2780063,"country":"Australia"},{"id":"c144","name":"Luanda","lat":-8.83682,"lon":13.23432,"population":2776168,"country":"Angola"},{"id":"c145","name":"Baotou","lat":40.6516,"lon":109.84389,"population":2761700,"country":"China"},{"id":"c146","name":"Osaka","lat":34.69379,"lon":135.50107,"population":2753862,"country":"Japan"},{"id":"c147","name":"Linyi","lat":35.06306,"lon":118.34278,"population":2743843,"country":"China"},{"id":"c148","name":"Baoding","lat":38.87288,"lon":115.46246,"population":2739887,"country":"China"},{"id":"c149","name":"Kaohsiung","lat":22.61626,"lon":120.31333,"population":2737660,"country":"Taiwan"},{"id":"c150","name":"Brooklyn","lat":40.6501,"lon":-73.94958,"population":2736074,"country":"United States"},{"id":"c151","name":"Guayaquil","lat":-2.19616,"lon":-79.88621,"population":2723665,"country":"Ecuador"},{"id":"c152","name":"Belo Horizonte","lat":-19.92083,"lon":-43.93778,"population":2721564,"country":"Brazil"},{"id":"c153","name":"Minhang","lat":31.10881,"lon":121.37471,"population":2716600,"country":"China"},{"id":"c154","name":"Bazhong","lat":31.8694,"lon":106.74432,"population":2712894,"country":"China"},{"id":"c155","name":"Salvador","lat":-12.97563,"lon":-38.49096,"population":2711840,"country":"Brazil"},{"id":"c156","name":"Abuja","lat":9.05785,"lon":7.49508,"population":2690000,"country":"Nigeria"},{"id":"c157","name":"Gazipur","lat":23.99844,"lon":90.42234,"population":2674697,"country":"Bangladesh"},{"id":"c158","name":"Chicago","lat":41.85003,"lon":-87.65005,"population":2664452,"country":"United States"},{"id":"c159","name":"Wenzhou","lat":27.99942,"lon":120.66682,"population":2650000,"country":"China"},{"id":"c160","name":"Bekasi","lat":-6.2349,"lon":106.9896,"population":2648272,"country":"Indonesia"},{"id":"c161","name":"Dakar","lat":14.6937,"lon":-17.44406,"population":2646503,"country":"Senegal"},{"id":"c162","name":"Haiphong","lat":20.86481,"lon":106.68345,"population":2625200,"country":"Vietnam"},{"id":"c163","name":"Yunfu","lat":22.92787,"lon":112.03809,"population":2612800,"country":"China"},{"id":"c164","name":"Navi Mumbai","lat":19.03681,"lon":73.01582,"population":2600000,"country":"India"},{"id":"c165","name":"Mogadishu","lat":2.03711,"lon":45.34375,"population":2587183,"country":"Somalia"},{"id":"c166","name":"Kumasi","lat":6.68848,"lon":-1.62443,"population":2544530,"country":"Ghana"},{"id":"c167","name":"Bandung","lat":-6.92222,"lon":107.60694,"population":2528163,"country":"Indonesia"},{"id":"c168","name":"Gujranwala","lat":32.15567,"lon":74.18705,"population":2511118,"country":"Pakistan"},{"id":"c169","name":"Medan","lat":3.58333,"lon":98.66667,"population":2486283,"country":"Indonesia"},{"id":"c170","name":"Lucknow","lat":26.83928,"lon":80.92313,"population":2472011,"country":"India"},{"id":"c171","name":"Xining","lat":36.62554,"lon":101.75739,"population":2467965,"country":"China"},{"id":"c172","name":"Ouagadougou","lat":12.36566,"lon":-1.53388,"population":2415266,"country":"Burkina Faso"},{"id":"c173","name":"Nagpur","lat":21.14631,"lon":79.08491,"population":2405665,"country":"India"},{"id":"c174","name":"Fortaleza","lat":-3.71722,"lon":-38.54306,"population":2400000,"country":"Brazil"},{"id":"c175","name":"Cali","lat":3.43054,"lon":-76.5199,"population":2392877,"country":"Colombia"},{"id":"c176","name":"Perth","lat":-31.95224,"lon":115.8614,"population":2384371,"country":"Australia"},{"id":"c177","name":"Daegu","lat":35.87102,"lon":128.60121,"population":2365523,"country":"South Korea"},{"id":"c178","name":"Algiers","lat":36.73225,"lon":3.08746,"population":2364230,"country":"Algeria"},{"id":"c179","name":"Nanchang","lat":28.68396,"lon":115.85306,"population":2357839,"country":"China"},{"id":"c180","name":"Baku","lat":40.37767,"lon":49.89201,"population":2351300,"country":"Azerbaijan"},{"id":"c181","name":"Nagoya","lat":35.18147,"lon":136.90641,"population":2332176,"country":"Japan"},{"id":"c182","name":"Rome","lat":41.89193,"lon":12.51133,"population":2318895,"country":"Italy"},{"id":"c183","name":"Queens","lat":40.68149,"lon":-73.83652,"population":2316841,"country":"United States"},{"id":"c184","name":"Houston","lat":29.76328,"lon":-95.36327,"population":2314157,"country":"United States"},{"id":"c185","name":"Mashhad","lat":36.29807,"lon":59.60567,"population":2307177,"country":"Iran"},{"id":"c186","name":"Shaoxing","lat":30.00237,"lon":120.57864,"population":2300000,"country":"China"},{"id":"c187","name":"Nantong","lat":32.03028,"lon":120.87472,"population":2273326,"country":"China"},{"id":"c188","name":"Baoshan","lat":31.40845,"lon":121.48956,"population":2265900,"country":"China"},{"id":"c189","name":"Kowloon","lat":22.31667,"lon":114.18333,"population":2232339,"country":"Hong Kong SAR China"},{"id":"c190","name":"Gaziantep","lat":37.05944,"lon":37.3825,"population":2222415,"country":"Türkiye"},{"id":"c191","name":"Lubumbashi","lat":-11.66089,"lon":27.47938,"population":2221925,"country":"Congo - Kinshasa"},{"id":"c192","name":"Manaus","lat":-3.10194,"lon":-60.025,"population":2219580,"country":"Brazil"},{"id":"c193","name":"Lusaka","lat":-15.40669,"lon":28.28713,"population":2212301,"country":"Zambia"},{"id":"c194","name":"Brasília","lat":-15.77972,"lon":-47.92972,"population":2207718,"country":"Brazil"},{"id":"c195","name":"Zhuhai","lat":22.27694,"lon":113.56778,"population":2207090,"country":"China"},{"id":"c196","name":"Santo Domingo","lat":18.47186,"lon":-69.89232,"population":2201941,"country":"Dominican Republic"},{"id":"c197","name":"Lomé","lat":6.12874,"lon":1.22154,"population":2188376,"country":"Togo"},{"id":"c198","name":"Multan","lat":30.19679,"lon":71.47824,"population":2169915,"country":"Pakistan"},{"id":"c199","name":"Havana","lat":23.13302,"lon":-82.38304,"population":2163824,"country":"Cuba"},{"id":"c200","name":"Depok","lat":-6.4,"lon":106.81861,"population":2163635,"country":"Indonesia"},{"id":"c201","name":"Ordos","lat":39.6086,"lon":109.78157,"population":2153638,"country":"China"},{"id":"c202","name":"Paris","lat":48.85341,"lon":2.3488,"population":2138551,"country":"France"},{"id":"c203","name":"Coimbatore","lat":11.00555,"lon":76.96612,"population":2136916,"country":"India"},{"id":"c204","name":"Qingyang","lat":35.70976,"lon":107.64455,"population":2125400,"country":"China"},{"id":"c205","name":"Port Harcourt","lat":4.77742,"lon":7.0134,"population":2120000,"country":"Nigeria"},{"id":"c206","name":"Pretoria","lat":-25.74486,"lon":28.18783,"population":2112693,"country":"South Africa"},{"id":"c207","name":"Córdoba","lat":-31.40648,"lon":-64.18853,"population":2106734,"country":"Argentina"},{"id":"c208","name":"Mbuji-Mayi","lat":-6.13603,"lon":23.58979,"population":2101332,"country":"Congo - Kinshasa"},{"id":"c209","name":"Aleppo","lat":36.20124,"lon":37.16117,"population":2098210,"country":"Syria"},{"id":"c210","name":"Kunshan","lat":31.37762,"lon":120.95431,"population":2092496,"country":"China"},{"id":"c211","name":"Al Mawşil al Jadīdah","lat":36.33271,"lon":43.10555,"population":2065597,"country":"Iraq"},{"id":"c212","name":"Zunyi","lat":27.68667,"lon":106.90722,"population":2037775,"country":"China"},{"id":"c213","name":"La Paz","lat":-16.5,"lon":-68.15,"population":2004652,"country":"Bolivia"},{"id":"c214","name":"Lianyungang","lat":34.59845,"lon":119.21556,"population":2001009,"country":"China"},{"id":"c215","name":"Medellín","lat":6.245,"lon":-75.57151,"population":1999979,"country":"Colombia"},{"id":"c216","name":"Puning","lat":23.31072,"lon":116.16869,"population":1998619,"country":"China"},{"id":"c217","name":"Indore","lat":22.71792,"lon":75.8333,"population":1994397,"country":"India"},{"id":"c218","name":"Brazzaville","lat":-4.26613,"lon":15.28318,"population":1982000,"country":"Congo - Brazzaville"},{"id":"c219","name":"Tashkent","lat":41.26465,"lon":69.21627,"population":1978028,"country":"Uzbekistan"},{"id":"c220","name":"Ganzhou","lat":25.84664,"lon":114.9326,"population":1977253,"country":"China"},{"id":"c221","name":"Almaty","lat":43.25249,"lon":76.9115,"population":1977011,"country":"Kazakhstan"},{"id":"c222","name":"Khartoum","lat":15.55177,"lon":32.53241,"population":1974647,"country":"Sudan"},{"id":"c223","name":"Hamburg","lat":53.55073,"lon":9.99302,"population":1973896,"country":"Germany"},{"id":"c224","name":"Sapporo","lat":43.06667,"lon":141.35,"population":1973832,"country":"Japan"},{"id":"c225","name":"Songjiang","lat":31.03443,"lon":121.22326,"population":1973500,"country":"China"},{"id":"c226","name":"Accra","lat":5.55602,"lon":-0.1969,"population":1963264,"country":"Ghana"},{"id":"c227","name":"Curitiba","lat":-25.42778,"lon":-49.27306,"population":1948626,"country":"Brazil"},{"id":"c228","name":"Sanaa","lat":15.35452,"lon":44.20646,"population":1937451,"country":"Yemen"},{"id":"c229","name":"Conakry","lat":9.53795,"lon":-13.67729,"population":1928389,"country":"Guinea"},{"id":"c230","name":"Tangerang","lat":-6.17806,"lon":106.63,"population":1927815,"country":"Indonesia"},{"id":"c231","name":"Tijuana","lat":32.5027,"lon":-117.00371,"population":1922523,"country":"Mexico"},{"id":"c232","name":"Hyderabad","lat":25.39689,"lon":68.37718,"population":1921275,"country":"Pakistan"},{"id":"c233","name":"Beirut","lat":33.89332,"lon":35.50157,"population":1916100,"country":"Lebanon"},{"id":"c234","name":"Jieyang","lat":23.5418,"lon":116.36581,"population":1899394,"country":"China"},{"id":"c235","name":"Jilin","lat":43.84652,"lon":126.5608,"population":1895865,"country":"China"},{"id":"c236","name":"Jiading","lat":31.38575,"lon":121.24465,"population":1886100,"country":"China"},{"id":"c237","name":"Bucharest","lat":44.43225,"lon":26.10626,"population":1877155,"country":"Romania"},{"id":"c238","name":"Camayenne","lat":9.535,"lon":-13.68778,"population":1871242,"country":"Guinea"},{"id":"c239","name":"Kakamega","lat":0.28422,"lon":34.75229,"population":1867579,"country":"Kenya"},{"id":"c240","name":"Shangqiu","lat":34.4143,"lon":115.65613,"population":1859723,"country":"China"},{"id":"c241","name":"Nanchong","lat":30.79508,"lon":106.08473,"population":1858875,"country":"China"},{"id":"c242","name":"Tainan","lat":22.99259,"lon":120.20507,"population":1856642,"country":"Taiwan"},{"id":"c243","name":"Kaduna","lat":10.52641,"lon":7.43879,"population":1850000,"country":"Nigeria"},{"id":"c244","name":"Omdurman","lat":15.64453,"lon":32.47773,"population":1849659,"country":"Sudan"},{"id":"c245","name":"Davao","lat":7.07306,"lon":125.61278,"population":1848947,"country":"Philippines"},{"id":"c246","name":"Thāne","lat":19.19704,"lon":72.96355,"population":1841488,"country":"India"},{"id":"c247","name":"Iztapalapa","lat":19.35529,"lon":-99.06224,"population":1835486,"country":"Mexico"},{"id":"c248","name":"Diyarbakır","lat":37.91363,"lon":40.21721,"population":1833684,"country":"Türkiye"},{"id":"c249","name":"Santa Cruz de la Sierra","lat":-17.78629,"lon":-63.18117,"population":1831434,"country":"Bolivia"},{"id":"c250","name":"Vadodara","lat":22.29941,"lon":73.20812,"population":1822221,"country":"India"},{"id":"c251","name":"Adana","lat":36.98615,"lon":35.32531,"population":1816750,"country":"Türkiye"},{"id":"c252","name":"Nanyang","lat":33.00524,"lon":112.54659,"population":1811812,"country":"China"},{"id":"c253","name":"Abu Dhabi","lat":24.45118,"lon":54.39696,"population":1807000,"country":"United Arab Emirates"},{"id":"c254","name":"Palembang","lat":-2.91673,"lon":104.7458,"population":1801367,"country":"Indonesia"},{"id":"c255","name":"Sharjah","lat":25.3342,"lon":55.41221,"population":1800000,"country":"United Arab Emirates"},{"id":"c256","name":"Bhopal","lat":23.25469,"lon":77.40289,"population":1798218,"country":"India"},{"id":"c257","name":"Jiangmen","lat":22.58333,"lon":113.08333,"population":1795459,"country":"China"},{"id":"c258","name":"Benin City","lat":6.33815,"lon":5.62575,"population":1782000,"country":"Nigeria"},{"id":"c259","name":"Jiangyin","lat":31.91102,"lon":120.26302,"population":1779515,"country":"China"},{"id":"c260","name":"Fuyang","lat":32.9,"lon":115.81667,"population":1768947,"country":"China"},{"id":"c261","name":"Montréal","lat":45.50884,"lon":-73.58781,"population":1762949,"country":"Canada"},{"id":"c262","name":"Bayan Nur","lat":40.74143,"lon":107.38599,"population":1760000,"country":"China"},{"id":"c263","name":"Chengtangcun","lat":35.08357,"lon":117.19071,"population":1756300,"country":"China"},{"id":"c264","name":"Maracaibo","lat":10.64232,"lon":-71.61089,"population":1752602,"country":"Venezuela"},{"id":"c265","name":"Chaozhou","lat":23.65396,"lon":116.62262,"population":1750945,"country":"China"},{"id":"c266","name":"Minsk","lat":53.90019,"lon":27.56653,"population":1742124,"country":"Belarus"},{"id":"c267","name":"Budapest","lat":47.49835,"lon":19.04045,"population":1741041,"country":"Hungary"},{"id":"c268","name":"Qingyuan","lat":23.7,"lon":113.03333,"population":1738424,"country":"China"},{"id":"c269","name":"Tai’an","lat":36.18528,"lon":117.12,"population":1735425,"country":"China"},{"id":"c270","name":"Rasapūdipalem","lat":17.73308,"lon":83.31622,"population":1728128,"country":"India"},{"id":"c271","name":"Pimpri-Chinchwad","lat":18.61867,"lon":73.80375,"population":1727692,"country":"India"},{"id":"c272","name":"Caloocan","lat":14.64953,"lon":120.96788,"population":1712945,"country":"Philippines"},{"id":"c273","name":"Warsaw","lat":52.22977,"lon":21.01178,"population":1702139,"country":"Poland"},{"id":"c274","name":"Soweto","lat":-26.26781,"lon":27.85849,"population":1695047,"country":"South Africa"},{"id":"c275","name":"Semarang","lat":-6.99306,"lon":110.42083,"population":1694740,"country":"Indonesia"},{"id":"c276","name":"Puebla","lat":19.04778,"lon":-98.20723,"population":1692181,"country":"Mexico"},{"id":"c277","name":"Vienna","lat":48.20849,"lon":16.37208,"population":1691468,"country":"Austria"},{"id":"c278","name":"Barcelona","lat":41.38879,"lon":2.15899,"population":1686208,"country":"Spain"},{"id":"c279","name":"Patna","lat":25.59408,"lon":85.13563,"population":1684297,"country":"India"},{"id":"c280","name":"Mosul","lat":36.335,"lon":43.11889,"population":1683000,"country":"Iraq"},{"id":"c281","name":"Kallakurichi","lat":11.73379,"lon":78.95925,"population":1682687,"country":"India"},{"id":"c282","name":"Kampala","lat":0.31628,"lon":32.58219,"population":1680600,"country":"Uganda"},{"id":"c283","name":"Changshu","lat":31.64615,"lon":120.74221,"population":1677050,"country":"China"},{"id":"c284","name":"Rabat","lat":34.01325,"lon":-6.83255,"population":1655753,"country":"Morocco"},{"id":"c285","name":"Recife","lat":-8.05389,"lon":-34.88111,"population":1653461,"country":"Brazil"},{"id":"c286","name":"Phoenix","lat":33.44838,"lon":-112.07404,"population":1650070,"country":"United States"},{"id":"c287","name":"Suzhou","lat":33.63611,"lon":116.97889,"population":1647642,"country":"China"},{"id":"c288","name":"Ecatepec de Morelos","lat":19.60006,"lon":-99.04855,"population":1645352,"country":"Mexico"},{"id":"c289","name":"Lu’an","lat":31.73561,"lon":116.51688,"population":1644344,"country":"China"},{"id":"c290","name":"Valencia","lat":10.16153,"lon":-68.00044,"population":1619470,"country":"Venezuela"},{"id":"c291","name":"Ludhiana","lat":30.91204,"lon":75.85379,"population":1618879,"country":"India"},{"id":"c292","name":"Yancheng","lat":33.3575,"lon":120.1573,"population":1615717,"country":"China"},{"id":"c293","name":"Novosibirsk","lat":55.02259,"lon":82.93175,"population":1612833,"country":"Russia"},{"id":"c294","name":"Erbil","lat":36.19117,"lon":44.00943,"population":1612700,"country":"Iraq"},{"id":"c295","name":"Fukuoka","lat":33.6,"lon":130.41667,"population":1612392,"country":"Japan"},{"id":"c296","name":"Taizhou","lat":32.49069,"lon":119.90812,"population":1607108,"country":"China"},{"id":"c297","name":"Daqing","lat":46.58333,"lon":125,"population":1604027,"country":"China"},{"id":"c298","name":"Kisangani","lat":0.51528,"lon":25.19099,"population":1602144,"country":"Congo - Kinshasa"},{"id":"c299","name":"Manila","lat":14.6042,"lon":120.9822,"population":1600000,"country":"Philippines"},{"id":"c300","name":"Wuhu","lat":31.35259,"lon":118.42947,"population":1598165,"country":"China"},{"id":"c301","name":"Santiago de Querétaro","lat":20.58806,"lon":-100.38806,"population":1594212,"country":"Mexico"},{"id":"c302","name":"Dazhou","lat":31.2106,"lon":107.46308,"population":1589435,"country":"China"},{"id":"c303","name":"León de los Aldama","lat":21.12183,"lon":-101.68253,"population":1579803,"country":"Mexico"},{"id":"c304","name":"Makkah","lat":21.42664,"lon":39.82563,"population":1578722,"country":"Saudi Arabia"},{"id":"c305","name":"Philadelphia","lat":39.95238,"lon":-75.16362,"population":1573916,"country":"United States"},{"id":"c306","name":"Phnom Penh","lat":11.56245,"lon":104.91601,"population":1573544,"country":"Cambodia"},{"id":"c307","name":"Guilin","lat":25.28022,"lon":110.29639,"population":1572300,"country":"China"},{"id":"c308","name":"Damascus","lat":33.5102,"lon":36.29128,"population":1569394,"country":"Syria"},{"id":"c309","name":"Quetta","lat":30.18414,"lon":67.00141,"population":1565546,"country":"Pakistan"},{"id":"c310","name":"Zhaoqing","lat":23.04893,"lon":112.46091,"population":1553109,"country":"China"},{"id":"c311","name":"Onitsha","lat":6.14978,"lon":6.78569,"population":1553000,"country":"Nigeria"},{"id":"c312","name":"Mianyang","lat":31.46784,"lon":104.68168,"population":1550000,"country":"China"},{"id":"c313","name":"Auckland","lat":-36.84853,"lon":174.76349,"population":1547200,"country":"New Zealand"},{"id":"c314","name":"Isfahan","lat":32.65246,"lon":51.67462,"population":1547164,"country":"Iran"},{"id":"c315","name":"Wanzhou","lat":30.76451,"lon":108.39586,"population":1545900,"country":"China"},{"id":"c316","name":"Astana","lat":51.1801,"lon":71.44598,"population":1544142,"country":"Kazakhstan"},{"id":"c317","name":"Harare","lat":-17.82772,"lon":31.05337,"population":1542813,"country":"Zimbabwe"},{"id":"c318","name":"Monrovia","lat":6.30054,"lon":-10.7969,"population":1542549,"country":"Liberia"},{"id":"c319","name":"Putian","lat":25.43944,"lon":119.01028,"population":1539389,"country":"China"},{"id":"c320","name":"Kawasaki","lat":35.52056,"lon":139.71722,"population":1538262,"country":"Japan"},{"id":"c321","name":"Goiânia","lat":-16.67861,"lon":-49.25389,"population":1536097,"country":"Brazil"},{"id":"c322","name":"San Antonio","lat":29.42412,"lon":-98.49363,"population":1526656,"country":"United States"},{"id":"c323","name":"Kobe","lat":34.6913,"lon":135.183,"population":1525152,"country":"Japan"},{"id":"c324","name":"Jinzhou","lat":41.10778,"lon":121.14167,"population":1524362,"country":"China"},{"id":"c325","name":"Stockholm","lat":59.32938,"lon":18.06871,"population":1515017,"country":"Sweden"},{"id":"c326","name":"Ciudad Juárez","lat":31.72024,"lon":-106.46084,"population":1512450,"country":"Mexico"},{"id":"c327","name":"Cần Thơ","lat":10.03711,"lon":105.78825,"population":1507187,"country":"Vietnam"},{"id":"c328","name":"Munich","lat":48.13743,"lon":11.57549,"population":1505005,"country":"Germany"},{"id":"c329","name":"Khulna","lat":22.80979,"lon":89.56439,"population":1500689,"country":"Bangladesh"},{"id":"c330","name":"Belém","lat":-1.45583,"lon":-48.50444,"population":1499641,"country":"Brazil"},{"id":"c331","name":"Yekaterinburg","lat":56.85733,"lon":60.61529,"population":1495066,"country":"Russia"},{"id":"c332","name":"Porto Alegre","lat":-30.03283,"lon":-51.23019,"population":1488252,"country":"Brazil"},{"id":"c333","name":"Manhattan","lat":40.78343,"lon":-73.96625,"population":1487536,"country":"United States"},{"id":"c334","name":"Nashik","lat":19.99727,"lon":73.79096,"population":1486053,"country":"India"},{"id":"c335","name":"Taizhou","lat":28.66266,"lon":121.43312,"population":1485502,"country":"China"},{"id":"c336","name":"Asunción","lat":-25.28646,"lon":-57.647,"population":1482200,"country":"Paraguay"},{"id":"c337","name":"Yiwu","lat":29.31506,"lon":120.07676,"population":1481384,"country":"China"},{"id":"c338","name":"Zapopan","lat":20.72111,"lon":-103.38742,"population":1476491,"country":"Mexico"},{"id":"c339","name":"Makassar","lat":-5.14861,"lon":119.43194,"population":1474393,"country":"Indonesia"},{"id":"c340","name":"Adelaide","lat":-34.92866,"lon":138.59863,"population":1469163,"country":"Australia"},{"id":"c341","name":"Quanzhou","lat":24.91389,"lon":118.58583,"population":1469157,"country":"China"},{"id":"c342","name":"Madurai","lat":9.919,"lon":78.11953,"population":1465625,"country":"India"},{"id":"c343","name":"Jinhua","lat":29.10678,"lon":119.64421,"population":1463990,"country":"China"},{"id":"c344","name":"Kyoto","lat":35.02107,"lon":135.75385,"population":1463723,"country":"Japan"},{"id":"c345","name":"Cixi","lat":30.1764,"lon":121.2457,"population":1457510,"country":"China"},{"id":"c346","name":"Changde","lat":29.03205,"lon":111.69844,"population":1457419,"country":"China"},{"id":"c347","name":"Kuala Lumpur","lat":3.1412,"lon":101.68653,"population":1453975,"country":"Malaysia"},{"id":"c348","name":"Kayseri","lat":38.73222,"lon":35.48528,"population":1452458,"country":"Türkiye"},{"id":"c349","name":"Kaifeng","lat":34.7986,"lon":114.30742,"population":1451741,"country":"China"},{"id":"c350","name":"Karaj","lat":35.83266,"lon":50.99155,"population":1448075,"country":"Iran"},{"id":"c351","name":"Kathmandu","lat":27.70169,"lon":85.3206,"population":1442271,"country":"Nepal"},{"id":"c352","name":"Daejeon","lat":36.35022,"lon":127.3848,"population":1441203,"country":"South Korea"},{"id":"c353","name":"Baoji","lat":34.36775,"lon":107.23705,"population":1437802,"country":"China"},{"id":"c354","name":"Suqian","lat":33.94917,"lon":118.29583,"population":1437685,"country":"China"},{"id":"c355","name":"Liuzhou","lat":24.32405,"lon":109.40698,"population":1436599,"country":"China"},{"id":"c356","name":"Tirunelveli","lat":8.72742,"lon":77.6838,"population":1435844,"country":"India"},{"id":"c357","name":"Konya","lat":37.87135,"lon":32.48464,"population":1433861,"country":"Türkiye"},{"id":"c358","name":"Zhangjiagang","lat":31.865,"lon":120.53889,"population":1432044,"country":"China"},{"id":"c359","name":"Agra","lat":27.18333,"lon":78.01667,"population":1430055,"country":"India"},{"id":"c360","name":"South Tangerang","lat":-6.28862,"lon":106.71789,"population":1429529,"country":"Indonesia"},{"id":"c361","name":"Tabriz","lat":38.08,"lon":46.2919,"population":1424641,"country":"Iran"},{"id":"c362","name":"Kharkiv","lat":49.98177,"lon":36.25475,"population":1421125,"country":"Ukraine"},{"id":"c363","name":"Xinyang","lat":32.12278,"lon":114.06556,"population":1416800,"country":"China"},{"id":"c364","name":"Jinjiang","lat":24.81978,"lon":118.57415,"population":1416151,"country":"China"},{"id":"c365","name":"Faridabad","lat":28.41124,"lon":77.31316,"population":1414050,"country":"India"},{"id":"c366","name":"Bozhou","lat":33.87722,"lon":115.77028,"population":1409436,"country":"China"},{"id":"c367","name":"Qujing","lat":25.48333,"lon":103.78333,"population":1408500,"country":"China"},{"id":"c368","name":"San Diego","lat":32.71571,"lon":-117.16472,"population":1404452,"country":"United States"},{"id":"c369","name":"Gwangju","lat":35.15472,"lon":126.91556,"population":1401235,"country":"South Korea"},{"id":"c370","name":"Zhanjiang","lat":21.23391,"lon":110.38749,"population":1400709,"country":"China"},{"id":"c371","name":"Fushun","lat":41.88669,"lon":123.94363,"population":1400646,"country":"China"},{"id":"c372","name":"Rājkot","lat":22.29161,"lon":70.79322,"population":1390640,"country":"India"},{"id":"c373","name":"Luoyang","lat":34.67345,"lon":112.43684,"population":1390581,"country":"China"},{"id":"c374","name":"Guadalajara","lat":20.67738,"lon":-103.34749,"population":1385629,"country":"Mexico"},{"id":"c375","name":"The Bronx","lat":40.84985,"lon":-73.86641,"population":1385108,"country":"United States"},{"id":"c376","name":"Guankou","lat":28.15861,"lon":113.62709,"population":1380000,"country":"China"},{"id":"c377","name":"Huế","lat":16.4619,"lon":107.59546,"population":1380000,"country":"Vietnam"},{"id":"c378","name":"Milan","lat":45.46427,"lon":9.18951,"population":1371498,"country":"Italy"},{"id":"c379","name":"Najafgarh","lat":28.60922,"lon":76.97982,"population":1365000,"country":"India"},{"id":"c380","name":"Lianjiang","lat":21.64673,"lon":110.28172,"population":1363470,"country":"China"},{"id":"c381","name":"N'Djamena","lat":12.10672,"lon":15.0444,"population":1359526,"country":"Chad"},{"id":"c382","name":"Handan","lat":36.60999,"lon":114.48764,"population":1358318,"country":"China"},{"id":"c383","name":"Bannu","lat":32.98527,"lon":70.60403,"population":1357890,"country":"Pakistan"},{"id":"c384","name":"Yichang","lat":30.71444,"lon":111.28472,"population":1350150,"country":"China"},{"id":"c385","name":"Antananarivo","lat":-18.91368,"lon":47.53613,"population":1349501,"country":"Madagascar"},{"id":"c386","name":"Heze","lat":35.23929,"lon":115.47358,"population":1346717,"country":"China"},{"id":"c387","name":"Guarulhos","lat":-23.46278,"lon":-46.53333,"population":1345364,"country":"Brazil"},{"id":"c388","name":"Abobo","lat":5.41613,"lon":-4.0159,"population":1340083,"country":"Côte d’Ivoire"},{"id":"c389","name":"Jamshedpur","lat":22.80278,"lon":86.18545,"population":1339438,"country":"India"},{"id":"c390","name":"Douala","lat":4.04827,"lon":9.70428,"population":1338082,"country":"Cameroon"},{"id":"c391","name":"Antalya","lat":36.90812,"lon":30.69556,"population":1335002,"country":"Türkiye"},{"id":"c392","name":"Basrah","lat":30.50852,"lon":47.7804,"population":1326564,"country":"Iraq"},{"id":"c393","name":"Dallas","lat":32.78306,"lon":-96.80667,"population":1326087,"country":"United States"},{"id":"c394","name":"Saitama","lat":35.90807,"lon":139.65657,"population":1324854,"country":"Japan"},{"id":"c395","name":"Niamey","lat":13.51366,"lon":2.1098,"population":1323691,"country":"Niger"},{"id":"c396","name":"Liupanshui","lat":26.59444,"lon":104.83333,"population":1320825,"country":"China"},{"id":"c397","name":"Taguig","lat":14.5243,"lon":121.0792,"population":1308085,"country":"Philippines"},{"id":"c398","name":"Maoming","lat":21.66625,"lon":110.91364,"population":1307802,"country":"China"},{"id":"c399","name":"Calgary","lat":51.05011,"lon":-114.08529,"population":1306784,"country":"Canada"},{"id":"c400","name":"Tripoli","lat":32.88743,"lon":13.18733,"population":1302947,"country":"Libya"},{"id":"c401","name":"Madinah","lat":24.46861,"lon":39.61417,"population":1300000,"country":"Saudi Arabia"},{"id":"c402","name":"Yaoundé","lat":3.86667,"lon":11.51667,"population":1299369,"country":"Cameroon"},{"id":"c403","name":"Batam","lat":1.14937,"lon":104.02491,"population":1296960,"country":"Indonesia"},{"id":"c404","name":"Qinzhou","lat":21.98247,"lon":108.65061,"population":1296300,"country":"China"},{"id":"c405","name":"Luohe","lat":33.57424,"lon":114.03261,"population":1294974,"country":"China"},{"id":"c406","name":"Xiangyang","lat":32.0422,"lon":112.14479,"population":1294733,"country":"China"},{"id":"c407","name":"Yangjiang","lat":21.85563,"lon":111.96272,"population":1292987,"country":"China"},{"id":"c408","name":"Yixing","lat":31.36059,"lon":119.82016,"population":1285785,"country":"China"},{"id":"c409","name":"Pimpri","lat":18.62292,"lon":73.80696,"population":1284606,"country":"India"},{"id":"c410","name":"Da Nang","lat":16.06778,"lon":108.22083,"population":1276000,"country":"Vietnam"},{"id":"c411","name":"Amman","lat":31.95522,"lon":35.94503,"population":1275857,"country":"Jordan"},{"id":"c412","name":"Budta","lat":7.20417,"lon":124.43972,"population":1273715,"country":"Philippines"},{"id":"c413","name":"Belgrade","lat":44.80401,"lon":20.46513,"population":1273651,"country":"Serbia"},{"id":"c414","name":"Biên Hòa","lat":10.94469,"lon":106.82432,"population":1272235,"country":"Vietnam"},{"id":"c415","name":"Kananga","lat":-5.89624,"lon":22.41659,"population":1271704,"country":"Congo - Kinshasa"},{"id":"c416","name":"Qingpu","lat":31.15394,"lon":121.11408,"population":1271424,"country":"China"},{"id":"c417","name":"Montevideo","lat":-34.90328,"lon":-56.18816,"population":1270737,"country":"Uruguay"},{"id":"c418","name":"Xuchang","lat":34.03189,"lon":113.86299,"population":1265536,"country":"China"},{"id":"c419","name":"Kalyān","lat":19.2437,"lon":73.13554,"population":1262255,"country":"India"},{"id":"c420","name":"Zigong","lat":29.34162,"lon":104.77689,"population":1262064,"country":"China"},{"id":"c421","name":"Nizhniy Novgorod","lat":56.32867,"lon":44.00205,"population":1259013,"country":"Russia"},{"id":"c422","name":"Jepara","lat":-6.5924,"lon":110.671,"population":1257912,"country":"Indonesia"},{"id":"c423","name":"Maputo","lat":-25.96553,"lon":32.58322,"population":1254837,"country":"Mozambique"},{"id":"c424","name":"Xuzhou","lat":34.20442,"lon":117.28386,"population":1253991,"country":"China"},{"id":"c425","name":"Dammam","lat":26.43442,"lon":50.10326,"population":1252523,"country":"Saudi Arabia"},{"id":"c426","name":"Ra’s Bayrūt","lat":33.9,"lon":35.48333,"population":1251739,"country":"Lebanon"},{"id":"c427","name":"Neijiang","lat":29.58354,"lon":105.06216,"population":1251095,"country":"China"},{"id":"c428","name":"Shiraz","lat":29.61031,"lon":52.53113,"population":1249942,"country":"Iran"},{"id":"c429","name":"Heshan","lat":28.56938,"lon":112.34733,"population":1249807,"country":"China"},{"id":"c430","name":"Dombivali","lat":19.21667,"lon":73.08333,"population":1247327,"country":"India"},{"id":"c431","name":"Kazan","lat":55.78874,"lon":49.12214,"population":1243500,"country":"Russia"},{"id":"c432","name":"Jining","lat":35.405,"lon":116.58139,"population":1241012,"country":"China"},{"id":"c433","name":"Barquisimeto","lat":10.0647,"lon":-69.35703,"population":1240714,"country":"Venezuela"},{"id":"c434","name":"Shubrā al Khaymah","lat":30.12511,"lon":31.25053,"population":1240289,"country":"Egypt"},{"id":"c435","name":"Putuo","lat":31.251,"lon":121.3897,"population":1239100,"country":"China"},{"id":"c436","name":"Port-au-Prince","lat":18.54349,"lon":-72.33881,"population":1234742,"country":"Haiti"},{"id":"c437","name":"Suwon","lat":37.27818,"lon":127.03164,"population":1234582,"country":"South Korea"},{"id":"c438","name":"Liaocheng","lat":36.45064,"lon":116.00247,"population":1229768,"country":"China"},{"id":"c439","name":"Jinzhong","lat":37.68403,"lon":112.75471,"population":1226617,"country":"China"},{"id":"c440","name":"Callao","lat":-12.05162,"lon":-77.13452,"population":1226200,"country":"Peru"},{"id":"c441","name":"Meerut","lat":28.98002,"lon":77.70636,"population":1223184,"country":"India"},{"id":"c442","name":"Virār","lat":19.45591,"lon":72.81136,"population":1222390,"country":"India"},{"id":"c443","name":"Nowrangapur","lat":19.23114,"lon":82.54826,"population":1220946,"country":"India"},{"id":"c444","name":"Karbala","lat":32.61603,"lon":44.02488,"population":1218732,"country":"Iraq"},{"id":"c445","name":"Changzhi","lat":36.18389,"lon":113.10528,"population":1214940,"country":"China"},{"id":"c446","name":"Tianshui","lat":34.57952,"lon":105.74238,"population":1212791,"country":"China"},{"id":"c447","name":"Sadr City","lat":33.3889,"lon":44.4583,"population":1211849,"country":"Iraq"},{"id":"c448","name":"Yangpu","lat":31.26193,"lon":121.51904,"population":1210800,"country":"China"},{"id":"c449","name":"Mombasa","lat":-4.05466,"lon":39.66359,"population":1208333,"country":"Kenya"},{"id":"c450","name":"Mandalay","lat":21.97473,"lon":96.08359,"population":1208099,"country":"Myanmar (Burma)"},{"id":"c451","name":"Srinagar","lat":34.08565,"lon":74.80555,"population":1206419,"country":"India"},{"id":"c452","name":"Barranquilla","lat":10.96854,"lon":-74.78132,"population":1206319,"country":"Colombia"},{"id":"c453","name":"Chelyabinsk","lat":55.1611,"lon":61.42877,"population":1202371,"country":"Russia"},{"id":"c454","name":"Mérida","lat":20.967,"lon":-89.62318,"population":1201000,"country":"Mexico"},{"id":"c455","name":"Hiroshima","lat":34.4,"lon":132.45,"population":1200754,"country":"Japan"},{"id":"c456","name":"Santiago de los Caballeros","lat":19.45036,"lon":-70.69085,"population":1200000,"country":"Dominican Republic"},{"id":"c457","name":"Shymkent","lat":42.30988,"lon":69.60042,"population":1200000,"country":"Kazakhstan"},{"id":"c458","name":"Weinan","lat":34.50355,"lon":109.50891,"population":1199290,"country":"China"},{"id":"c459","name":"Ghāziābād","lat":28.66535,"lon":77.43915,"population":1199191,"country":"India"},{"id":"c460","name":"Matola","lat":-25.96222,"lon":32.45889,"population":1198988,"country":"Mozambique"},{"id":"c461","name":"Dhanbad","lat":23.79759,"lon":86.42992,"population":1196214,"country":"India"},{"id":"c462","name":"Arequipa","lat":-16.39899,"lon":-71.53747,"population":1195700,"country":"Peru"},{"id":"c463","name":"Hong Kong Island","lat":22.26302,"lon":114.18419,"population":1195529,"country":"Hong Kong SAR China"},{"id":"c464","name":"Fes","lat":34.03313,"lon":-5.00028,"population":1191905,"country":"Morocco"},{"id":"c465","name":"Gustavo Adolfo Madero","lat":19.49392,"lon":-99.11075,"population":1185772,"country":"Mexico"},{"id":"c466","name":"Nouakchott","lat":18.08581,"lon":-15.9785,"population":1184530,"country":"Mauritania"},{"id":"c467","name":"Jiaxing","lat":30.7522,"lon":120.75,"population":1180000,"country":"China"},{"id":"c468","name":"Aurangabad","lat":19.87757,"lon":75.34226,"population":1175116,"country":"India"},{"id":"c469","name":"Zhongwei","lat":37.51129,"lon":105.19067,"population":1174600,"country":"China"},{"id":"c470","name":"Omsk","lat":54.99244,"lon":73.36859,"population":1172070,"country":"Russia"},{"id":"c471","name":"Pikine","lat":14.76457,"lon":-17.39071,"population":1170791,"country":"Senegal"},{"id":"c472","name":"Pekanbaru","lat":0.51667,"lon":101.44167,"population":1167599,"country":"Indonesia"},{"id":"c473","name":"Panjin","lat":41.121,"lon":122.0739,"population":1166481,"country":"China"},{"id":"c474","name":"Prague","lat":50.08804,"lon":14.42076,"population":1165581,"country":"Czechia"},{"id":"c475","name":"Varanasi","lat":25.31668,"lon":83.01041,"population":1164404,"country":"India"},{"id":"c476","name":"Jiujiang","lat":29.70475,"lon":116.00206,"population":1164268,"country":"China"},{"id":"c477","name":"Samara","lat":53.20767,"lon":50.13553,"population":1163399,"country":"Russia"},{"id":"c478","name":"Aba","lat":5.10658,"lon":7.36667,"population":1160000,"country":"Nigeria"},{"id":"c479","name":"Amritsar","lat":31.62234,"lon":74.87534,"population":1159227,"country":"India"},{"id":"c480","name":"Birmingham","lat":52.48142,"lon":-1.89983,"population":1157603,"country":"United Kingdom"},{"id":"c481","name":"Copenhagen","lat":55.67594,"lon":12.56553,"population":1153615,"country":"Denmark"},{"id":"c482","name":"Sofia","lat":42.69751,"lon":23.32415,"population":1152556,"country":"Bulgaria"},{"id":"c483","name":"Anyang","lat":36.096,"lon":114.38278,"population":1146839,"country":"China"},{"id":"c484","name":"Yerevan","lat":40.17765,"lon":44.5126,"population":1144700,"country":"Armenia"},{"id":"c485","name":"Luohu District","lat":22.54721,"lon":114.13149,"population":1143801,"country":"China"},{"id":"c486","name":"Vijayawada","lat":16.50745,"lon":80.6466,"population":1143232,"country":"India"},{"id":"c487","name":"Fengxiang","lat":30.85841,"lon":121.46779,"population":1140872,"country":"China"},{"id":"c488","name":"Bijie","lat":27.30193,"lon":105.28627,"population":1137383,"country":"China"},{"id":"c489","name":"Monterrey","lat":25.68435,"lon":-100.31721,"population":1135512,"country":"Mexico"},{"id":"c490","name":"Kigali","lat":-1.94995,"lon":30.05885,"population":1132686,"country":"Rwanda"},{"id":"c491","name":"Rostov-on-Don","lat":47.21997,"lon":39.70769,"population":1130305,"country":"Russia"},{"id":"c492","name":"Zhuzhou","lat":27.83333,"lon":113.15,"population":1129687,"country":"China"},{"id":"c493","name":"Rui’an","lat":27.77605,"lon":120.65859,"population":1125000,"country":"China"},{"id":"c494","name":"Malingao","lat":7.16083,"lon":124.475,"population":1121974,"country":"Philippines"},{"id":"c495","name":"Touba","lat":14.86229,"lon":-15.87532,"population":1120824,"country":"Senegal"},{"id":"c496","name":"Ufa","lat":54.74306,"lon":55.96779,"population":1120547,"country":"Russia"},{"id":"c497","name":"Ranchi","lat":23.34316,"lon":85.3094,"population":1120374,"country":"India"},{"id":"c498","name":"Zoucheng","lat":35.40056,"lon":116.96556,"population":1116692,"country":"China"},{"id":"c499","name":"Shangrao","lat":28.45179,"lon":117.94287,"population":1116486,"country":"China"},{"id":"c500","name":"Lilongwe","lat":-13.96692,"lon":33.78725,"population":1115815,"country":"Malawi"}],"spaceports":[{"id":"ksc","name":"Kennedy Space Center","lat":28.5729,"lon":-80.649,"country":"USA"},{"id":"baikonur","name":"Baikonur Cosmodrome","lat":45.965,"lon":63.305,"country":"Kazakhstan"},{"id":"kourou","name":"Guiana Space Centre","lat":5.2389,"lon":-52.7683,"country":"France"},{"id":"tanegashima","name":"Tanegashima Space Center","lat":30.4008,"lon":130.9681,"country":"Japan"},{"id":"sriharikota","name":"Satish Dhawan Space Centre","lat":13.7199,"lon":80.2304,"country":"India"},{"id":"wenchang","name":"Wenchang Space Launch Site","lat":19.6146,"lon":110.9513,"country":"China"},{"id":"vandenberg","name":"Vandenberg Space Force Base","lat":34.742,"lon":-120.5724,"country":"USA"},{"id":"starbase","name":"Starbase","lat":25.9973,"lon":-97.1551,"country":"USA"}]};

const EARTH_ROUTE_RADIUS_KM = 6371;

/**
 * Convert degrees to radians.
 * @param {number} degrees Angle in degrees.
 * @returns {number} Angle in radians.
 */
function toRadians(degrees) {
  return degrees * Math.PI / 180;
}

/**
 * Great-circle distance using the haversine formula and a 6,371 km mean Earth radius.
 * @param {number} lat1 Latitude of the first point in degrees.
 * @param {number} lon1 Longitude of the first point in degrees.
 * @param {number} lat2 Latitude of the second point in degrees.
 * @param {number} lon2 Longitude of the second point in degrees.
 * @returns {number} Great-circle distance in kilometres.
 */
export function greatCircleKm(lat1, lon1, lat2, lon2) {
  const phi1 = toRadians(lat1);
  const phi2 = toRadians(lat2);
  const deltaPhi = toRadians(lat2 - lat1);
  const deltaLambda = toRadians(lon2 - lon1);
  const a = Math.sin(deltaPhi / 2) ** 2 +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) ** 2;
  return 2 * EARTH_ROUTE_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

const cityNodes = EARTH_CITY_DATA.cities.map((city) => ({ ...city }));
const spaceportNodes = EARTH_CITY_DATA.spaceports.map((spaceport) => ({
  ...spaceport,
  population: 0
}));
const allNodes = [...cityNodes, ...spaceportNodes];
const nodeById = new Map(allNodes.map((node) => [node.id, node]));

/**
 * Minimum spanning tree edges, calculated with Prim's algorithm.
 * This guarantees that the route graph is connected even when nearest-neighbour
 * links do not span an ocean or remote launch site.
 * @returns {Array<{a: string, b: string, km: number}>} Undirected graph edges.
 */
function buildMinimumSpanningTree() {
  const connected = new Set([allNodes.at(0).id]);
  const remaining = new Set(allNodes.slice(1).map((node) => node.id));
  const edges = [];

  while (remaining.size) {
    let best = null;

    for (const fromId of connected) {
      const from = nodeById.get(fromId);
      for (const toId of remaining) {
        const to = nodeById.get(toId);
        const km = greatCircleKm(from.lat, from.lon, to.lat, to.lon);
        if (!best || km < best.km) best = { a: fromId, b: toId, km };
      }
    }

    edges.push(best);
    connected.add(best.b);
    remaining.delete(best.b);
  }

  return edges;
}

const LONG_HAUL_ROUTES = [
  ['ksc', 'kourou'],
  ['ksc', 'baikonur'],
  ['kourou', 'tanegashima'],
  ['baikonur', 'sriharikota'],
  ['sriharikota', 'wenchang'],
  ['wenchang', 'tanegashima'],
  ['vandenberg', 'ksc'],
  ['vandenberg', 'starbase'],
  ['starbase', 'ksc'],
  ['kourou', 'sriharikota']
];

/**
 * Build the undirected Earth route graph.
 * @returns {{nodes: Array<object>, edges: Array<object>}} Graph nodes and edges.
 */
function buildGraph() {
  const edgeKey = new Set();
  const edges = [];

  /**
   * Add an undirected edge if it does not already exist.
   * @param {string} a First node ID.
   * @param {string} b Second node ID.
   * @returns {void}
   */
  function addEdge(a, b) {
    if (a === b) return;
    const key = a < b ? a + '|' + b : b + '|' + a;
    if (edgeKey.has(key)) return;
    const from = nodeById.get(a);
    const to = nodeById.get(b);
    edgeKey.add(key);
    edges.push({
      a,
      b,
      km: greatCircleKm(from.lat, from.lon, to.lat, to.lon)
    });
  }

  // Four nearest neighbours give dense local and regional connectivity.
  for (const from of allNodes) {
    const neighbours = allNodes
      .filter((to) => to.id !== from.id)
      .map((to) => ({
        id: to.id,
        km: greatCircleKm(from.lat, from.lon, to.lat, to.lon)
      }))
      .sort((a, b) => a.km - b.km)
      .slice(0, 6);

    for (const neighbour of neighbours) addEdge(from.id, neighbour.id);
  }

  // A spanning tree guarantees that every city and spaceport is reachable.
  for (const edge of buildMinimumSpanningTree()) addEdge(edge.a, edge.b);

  // Predefined intercontinental launch-site routes.
  for (const [a, b] of LONG_HAUL_ROUTES) addEdge(a, b);

  return { nodes: allNodes, edges };
}

const earthGraph = buildGraph();

/**
 * Find the graph node nearest to a geographic coordinate.
 * @param {number} lat Latitude in degrees.
 * @param {number} lon Longitude in degrees.
 * @returns {object} The nearest city node.
 */
export function nearestCity(lat, lon) {
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    throw new Error('Latitude and longitude must be finite numbers.');
  }

  let best = null;
  let bestKm = Infinity;

  for (const node of cityNodes) {
    const km = greatCircleKm(lat, lon, node.lat, node.lon);
    if (km < bestKm) {
      best = node;
      bestKm = km;
    }
  }

  return best;
}

/**
 * Find the shortest route between two graph nodes using Dijkstra's algorithm.
 * @param {string} fromId Start node ID.
 * @param {string} toId Destination node ID.
 * @returns {{path: string[], km: number}|null} Route and total distance, or null when unreachable.
 */
export function dijkstra(fromId, toId) {
  const from = nodeById.get(fromId);
  const to = nodeById.get(toId);
  if (!from || !to) return null;

  const adjacency = new Map(allNodes.map((node) => [node.id, []]));
  for (const edge of earthGraph.edges) {
    adjacency.get(edge.a).push({ id: edge.b, km: edge.km });
    adjacency.get(edge.b).push({ id: edge.a, km: edge.km });
  }

  const distances = new Map(allNodes.map((node) => [node.id, Infinity]));
  const previous = new Map();
  const visited = new Set();
  distances.set(fromId, 0);

  while (true) {
    let currentId = null;
    let currentDistance = Infinity;

    for (const [id, distance] of distances) {
      if (!visited.has(id) && distance < currentDistance) {
        currentId = id;
        currentDistance = distance;
      }
    }

    if (currentId === null || currentId === toId) break;
    visited.add(currentId);

    for (const neighbour of adjacency.get(currentId)) {
      if (visited.has(neighbour.id)) continue;
      const candidate = currentDistance + neighbour.km;
      if (candidate < distances.get(neighbour.id)) {
        distances.set(neighbour.id, candidate);
        previous.set(neighbour.id, currentId);
      }
    }
  }

  if (!Number.isFinite(distances.get(toId))) return null;

  const path = [toId];
  let cursor = toId;
  while (cursor !== fromId) {
    cursor = previous.get(cursor);
    path.unshift(cursor);
  }

  return { path, km: distances.get(toId) };
}

/**
 * Return cities whose country name contains the requested region.
 * @param {string} region Country or region name, case-insensitive.
 * @returns {Array<object>} Matching city nodes.
 */
export function citiesFromRegion(region) {
  const query = String(region).trim().toLowerCase();
  if (!query) return [];
  return cityNodes.filter((city) => city.country.toLowerCase().includes(query));
}

/**
 * Earth city and spaceport routing API.
 */
export const EarthRoute = {
  graph: earthGraph,
  loadGraph: async () => undefined,
  nearestCity,
  dijkstra,
  greatCircleKm,
  airportCount: spaceportNodes.length,
  citiesFromRegion,
  SPACEPORTS: EARTH_CITY_DATA.spaceports
};
if (typeof window !== 'undefined') {
  window.LLP = window.LLP || {};
  window.LLP.EarthRoute = EarthRoute;
}
