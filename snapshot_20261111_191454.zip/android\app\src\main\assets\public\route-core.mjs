/**
 * Intuitive city-to-city and planet-to-planet routing for Lunar Link Planner.
 *
 * Public browser API:
 *   window.LLP.Routing.planRoute(from, to)
 *   window.LLP.Routing.getActiveRoute()
 *   window.LLP.Routing.setActiveRoute(route)
 *
 * Route input:
 *   { type:'city', lat, lon, name }
 *   { type:'planet', id, name }
 *
 * Route output:
 *   {
 *     distanceKm, durationHours, isValid,
 *     path: [{lat,lon}] | [{planetId,x,y,z}],
 *     waypoints: []
 *   }
 */

const EARTH_RADIUS_KM = 6371.0088;
const MU_SUN_KM3_S2 = 1.32712440018e11;
const AU_KM = 149597870.7;
const MAX_CITY_WAYPOINTS = 20;
const DEFAULT_TRAVEL_SPEED_KMH = 100;

let activeRoute = null;
let citiesCache = null;
let citiesLoadPromise = null;

const FALLBACK_PLANETS = {
  sun: { id: 'sun', name: 'Sun', semiMajorAxisKm: 0 },
  mercury: { id: 'mercury', name: 'Mercury', semiMajorAxisKm: 0.38709893 * AU_KM },
  venus: { id: 'venus', name: 'Venus', semiMajorAxisKm: 0.72333199 * AU_KM },
  earth: { id: 'earth', name: 'Earth', semiMajorAxisKm: 1.495978707e8 },
  mars: { id: 'mars', name: 'Mars', semiMajorAxisKm: 1.52366231 * AU_KM },
  jupiter: { id: 'jupiter', name: 'Jupiter', semiMajorAxisKm: 5.20336301 * AU_KM },
  saturn: { id: 'saturn', name: 'Saturn', semiMajorAxisKm: 9.53707032 * AU_KM },
  uranus: { id: 'uranus', name: 'Uranus', semiMajorAxisKm: 19.19126393 * AU_KM },
  neptune: { id: 'neptune', name: 'Neptune', semiMajorAxisKm: 30.06896348 * AU_KM }
};

function toRadians(degrees) {
  return degrees * Math.PI / 180;
}

function toDegrees(radians) {
  return radians * 180 / Math.PI;
}

function normalizeDegrees(value) {
  let normalized = value % 360;
  if (normalized > 180) normalized -= 360;
  if (normalized < -180) normalized += 360;
  return normalized;
}

function haversineKm(lat1, lon1, lat2, lon2) {
  const phi1 = toRadians(lat1);
  const phi2 = toRadians(lat2);
  const dPhi = toRadians(lat2 - lat1);
  const dLambda = toRadians(lon2 - lon1);

  const a = Math.sin(dPhi / 2) ** 2 +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) ** 2;
  const centralAngle = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
  return EARTH_RADIUS_KM * centralAngle;
}

function greatCirclePoint(lat1, lon1, lat2, lon2, fraction) {
  const phi1 = toRadians(lat1);
  const lambda1 = toRadians(lon1);
  const phi2 = toRadians(lat2);
  const lambda2 = toRadians(lon2);

  const dLambda = lambda2 - lambda1;
  const cosPhi1 = Math.cos(phi1);
  const cosPhi2 = Math.cos(phi2);
  const sinPhi1 = Math.sin(phi1);
  const sinPhi2 = Math.sin(phi2);

  const x = cosPhi1 * sinPhi2 - sinPhi1 * cosPhi2 * Math.cos(dLambda);
  const y = cosPhi2 * Math.sin(dLambda);
  const z = sinPhi1 * sinPhi2 + cosPhi1 * cosPhi2 * Math.cos(dLambda);

  const centralAngle = Math.atan2(Math.hypot(x, y), z);
  if (!Number.isFinite(centralAngle) || centralAngle === 0) {
    return { lat: lat1, lon: lon1 };
  }

  const sinTotal = Math.sin(centralAngle);
  const a = Math.sin((1 - fraction) * centralAngle) / sinTotal;
  const b = Math.sin(fraction * centralAngle) / sinTotal;

  const x3 = a * cosPhi1 * Math.cos(lambda1) + b * cosPhi2 * Math.cos(lambda2);
  const y3 = a * cosPhi1 * Math.sin(lambda1) + b * cosPhi2 * Math.sin(lambda2);
  const z3 = a * sinPhi1 + b * sinPhi2;

  const lat = toDegrees(Math.atan2(z3, Math.hypot(x3, y3)));
  const lon = toDegrees(Math.atan2(y3, x3));
  return { lat, lon: normalizeDegrees(lon) };
}

async function loadCities() {
  if (citiesCache) return citiesCache;
  if (citiesLoadPromise) return citiesLoadPromise;

  citiesLoadPromise = (async () => {
    try {
      let payload;
      try {
        const response = await fetch('data/cities-500.json');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        payload = await response.json();
      } catch (browserFetchError) {
        if (typeof process === 'undefined' || !process.versions?.node) {
          throw browserFetchError;
        }
        const { readFile } = await import('node:fs/promises');
        const { fileURLToPath } = await import('node:url');
        const here = new URL('.', import.meta.url);
        const filePath = fileURLToPath(new URL('data/cities-500.json', here));
        payload = JSON.parse(await readFile(filePath, 'utf8'));
      }
      const cities = Array.isArray(payload) ? payload : payload.cities;
      citiesCache = Array.isArray(cities) ? cities.filter(city =>
        city && typeof city.lat === 'number' && typeof city.lon === 'number'
      ) : [];
    } catch (error) {
      console.warn('[route-core] City data unavailable:', error && error.message);
      citiesCache = [];
    }
    return citiesCache;
  })();

  return citiesLoadPromise;
}

async function findCityByName(name) {
  const cities = await loadCities();
  const wanted = String(name || '').trim().toLowerCase();
  if (!wanted) return null;

  let best = null;
  let bestScore = -Infinity;

  for (const city of cities) {
    const cityName = String(city.name || '').toLowerCase();
    if (!cityName) continue;

    let score = 0;
    if (cityName === wanted) score = 3;
    else if (cityName.startsWith(wanted)) score = 2;
    else if (cityName.includes(wanted)) score = 1;

    if (score > bestScore) {
      bestScore = score;
      best = city;
    }
  }

  return bestScore > 0 ? best : null;
}

function getPlanet(id) {
  const wanted = String(id || '').toLowerCase();
  if (typeof window !== 'undefined' && window.LLP && window.LLP.Planets) {
    try {
      const planet = window.LLP.Planets.get(wanted);
      if (planet) return planet;
    } catch (error) {
      console.warn('[route-core] Planet lookup failed:', error && error.message);
    }
  }
  return FALLBACK_PLANETS[wanted] || null;
}

function hohmannTransferKm(a1Km, a2Km) {
  if (!(a1Km > 0) || !(a2Km > 0)) {
    return { distanceKm: 0, durationHours: 0, transferRadiusKm: 0 };
  }

  const transferRadiusKm = (a1Km + a2Km) / 2;
  const durationSeconds = Math.PI * Math.sqrt((transferRadiusKm ** 3) / MU_SUN_KM3_S2);
  return {
    distanceKm: Math.PI * transferRadiusKm,
    durationHours: durationSeconds / 3600,
    transferRadiusKm
  };
}

function planetPath(fromPlanet, toPlanet) {
  const a1 = fromPlanet.semiMajorAxisKm;
  const a2 = toPlanet.semiMajorAxisKm;
  const transfer = hohmannTransferKm(a1, a2);

  const path = [
    { planetId: fromPlanet.id, x: a1, y: 0, z: 0 },
    { planetId: toPlanet.id, x: a2, y: 0, z: 0 }
  ];

  return {
    distanceKm: transfer.distanceKm,
    durationHours: transfer.durationHours,
    path,
    waypoints: [fromPlanet.id, toPlanet.id]
  };
}

function invalidRoute(message) {
  return {
    distanceKm: 0,
    durationHours: 0,
    path: [],
    waypoints: [],
    isValid: false,
    error: message
  };
}

/**
 * Plan a direct city-to-city great-circle route or a simplified planet-to-planet
 * Hohmann transfer.
 *
 * @param {object} from Route origin.
 * @param {object} to Route destination.
 * @returns {Promise<object>} Route result.
 */
export async function planRoute(from, to) {
  if (!from || !to) return invalidRoute('Start and destination are required.');

  const fromType = String(from.type || '').toLowerCase();
  const toType = String(to.type || '').toLowerCase();

  if (fromType === 'city' && toType === 'city') {
    const lat1 = Number(from.lat);
    const lon1 = Number(from.lon);
    const lat2 = Number(to.lat);
    const lon2 = Number(to.lon);

    if (![lat1, lon1, lat2, lon2].every(Number.isFinite)) {
      return invalidRoute('City coordinates must be numeric.');
    }
    if (lat1 < -90 || lat1 > 90 || lat2 < -90 || lat2 > 90) {
      return invalidRoute('Latitude must be between -90 and 90 degrees.');
    }

    const distanceKm = haversineKm(lat1, lon1, lat2, lon2);
    const path = [{ lat: lat1, lon: normalizeDegrees(lon1) }];

    const pointCount = Math.max(2, Math.min(MAX_CITY_WAYPOINTS, 20));
    const segments = pointCount - 1;
    for (let index = 1; index < segments; index++) {
      const fraction = index / segments;
      const point = greatCirclePoint(lat1, lon1, lat2, lon2, fraction);
      path.push({ lat: point.lat, lon: point.lon });
    }

    path.push({ lat: lat2, lon: normalizeDegrees(lon2) });

    const route = {
      distanceKm,
      durationHours: distanceKm / DEFAULT_TRAVEL_SPEED_KMH,
      path,
      waypoints: [],
      isValid: true,
      type: 'city'
    };
    setActiveRoute(route);
    return route;
  }

  if (fromType === 'planet' && toType === 'planet') {
    const fromPlanet = getPlanet(from.id);
    const toPlanet = getPlanet(to.id);

    if (!fromPlanet || !toPlanet) {
      return invalidRoute('Unknown planet selected.');
    }
    if (fromPlanet.id === toPlanet.id) {
      return invalidRoute('Origin and destination planets must differ.');
    }
    if (fromPlanet.id === 'sun' || toPlanet.id === 'sun') {
      return invalidRoute('Hohmann transfers require planetary orbits.');
    }

    const route = planetPath(fromPlanet, toPlanet);
    route.isValid = true;
    route.type = 'planet';
    setActiveRoute(route);
    return route;
  }

  return invalidRoute('Start and destination must both be cities or both be planets.');
}

export function getActiveRoute() {
  return activeRoute;
}

export function setActiveRoute(route) {
  activeRoute = route || null;
  return activeRoute;
}

export async function findCity(query) {
  return findCityByName(query);
}

export async function loadCityOptions() {
  return loadCities();
}

const Routing = {
  planRoute,
  getActiveRoute,
  setActiveRoute,
  findCity,
  loadCityOptions
};

if (typeof window !== 'undefined') {
  window.LLP = window.LLP || {};
  window.LLP.Routing = Routing;
}

export default Routing;
