/**
 * Controls Core Module for Lunar Link Planner
 *
 * INTEGRATION IN app.js (Beispiel):
 * import { enable, update, setMode, focusBody, getCamera, disable } from './controls-core.mjs';
 *
 * // Nach Initialisierung von Kamera und Szene in app.js:
 * enable(camera, scene);
 *
 * // Im Render-Loop (deltaTime in Millisekunden):
 * let lastTime = performance.now();
 * function animate() {
 *   const now = performance.now();
 *   update(now - lastTime);
 *   lastTime = now;
 *   renderer.render(scene, camera);
 *   requestAnimationFrame(animate);
 * }
 * requestAnimationFrame(animate);
 */

import { tweenCamera } from './scene-tween.mjs';

// Inline Vektor-Hilfen (kein 'three'-Import, um Node-Safety zu wahren)
const v3 = (x=0,y=0,z=0) => ({x,y,z});
const vSub = (a,b) => v3(a.x-b.x, a.y-b.y, a.z-b.z);
const vCross = (a,b) => v3(a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x);
const vLen = (a) => Math.sqrt(a.x*a.x + a.y*a.y + a.z*a.z);
const vNorm = (a) => { const l = vLen(a) || 1; return v3(a.x/l, a.y/l, a.z/l); };

let camera = null;
let scene = null;
let enabled = false;
let currentMode = 'orbit';

// Interaktions-Status
let isDragging = false;
let isPanning = false;
let previousMousePosition = { x: 0, y: 0 };
let spherical = { radius: 100, phi: Math.PI / 2, theta: 0 };
let targetLookAt = { x: 0, y: 0, z: 0 };

// Inertia-Status
let velocity = { x: 0, y: 0 };
let zoomVelocity = 0;

// Konstanten für sanfte, Google-Maps-ähnliche Bewegung
const DAMPING = 0.90;
const ZOOM_DAMPING = 0.80;
const ROTATION_SPEED = 0.004;
const PAN_SPEED = 0.002;
const ZOOM_SPEED = 0.08;

// Touch-Status
let touchStartDist = 0;
let touchStartCenter = { x: 0, y: 0 };

function init(cameraRef, sceneRef) {
  if (typeof window === 'undefined') return;
  camera = cameraRef || (window.LLP && window.LLP.camera);
  scene = sceneRef || (window.LLP && window.LLP.scene);

  if (camera && camera.position) {
    const pos = camera.position;
    spherical.radius = Math.sqrt(pos.x * pos.x + pos.y * pos.y + pos.z * pos.z) || 100;
    spherical.phi = Math.acos(Math.max(-1, Math.min(1, pos.y / spherical.radius))) || Math.PI / 2;
    spherical.theta = Math.atan2(pos.x, pos.z) || 0;
    targetLookAt = { x: 0, y: 0, z: 0 };
  }
}

function enable(cameraRef, sceneRef) {
  if (typeof window === 'undefined') return;
  if (enabled) return; // Idempotent

  init(cameraRef, sceneRef);
  enabled = true;

  // Bestehende OrbitControls aus app.js deaktivieren, um Konflikte zu vermeiden
  if (window.LLP && window.LLP.controls && typeof window.LLP.controls.dispose === 'function') {
    window.LLP.controls.dispose();
    window.LLP.controls = null;
  }

  const canvas = document.querySelector('canvas');
  if (!canvas) return;

  canvas.addEventListener('mousedown', onMouseDown);
  canvas.addEventListener('mousemove', onMouseMove);
  canvas.addEventListener('mouseup', onMouseUp);
  canvas.addEventListener('mouseleave', onMouseUp);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  canvas.addEventListener('contextmenu', e => e.preventDefault());

  canvas.addEventListener('touchstart', onTouchStart, { passive: false });
  canvas.addEventListener('touchmove', onTouchMove, { passive: false });
  canvas.addEventListener('touchend', onTouchEnd);
  canvas.addEventListener('touchcancel', onTouchEnd);

  window.LLP = window.LLP || {};
  window.LLP.Controls = { enable, disable, focusBody, setMode, getCamera, update };
}

function disable() {
  if (typeof window === 'undefined') return;
  if (!enabled) return; // Idempotent
  enabled = false;

  const canvas = document.querySelector('canvas');
  if (!canvas) return;

  canvas.removeEventListener('mousedown', onMouseDown);
  canvas.removeEventListener('mousemove', onMouseMove);
  canvas.removeEventListener('mouseup', onMouseUp);
  canvas.removeEventListener('mouseleave', onMouseUp);
  canvas.removeEventListener('wheel', onWheel);

  canvas.removeEventListener('touchstart', onTouchStart);
  canvas.removeEventListener('touchmove', onTouchMove);
  canvas.removeEventListener('touchend', onTouchEnd);
  canvas.removeEventListener('touchcancel', onTouchEnd);
}

function onMouseDown(event) {
  if (!enabled || !camera) return;
  if (event.button === 0) {
    isDragging = true;
  } else if (event.button === 2) {
    isPanning = true;
  }
  previousMousePosition = { x: event.clientX, y: event.clientY };
  velocity = { x: 0, y: 0 };
  zoomVelocity = 0;
}

function onMouseMove(event) {
  if (!enabled || !camera) return;
  const deltaX = event.clientX - previousMousePosition.x;
  const deltaY = event.clientY - previousMousePosition.y;

  if (isDragging) {
    spherical.theta -= deltaX * ROTATION_SPEED;
    spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi - deltaY * ROTATION_SPEED));
    velocity = { x: -deltaX * ROTATION_SPEED, y: -deltaY * ROTATION_SPEED };
  } else if (isPanning) {
    // Screen-Space Panning: Bewege targetLookAt entlang der lokalen Rechts/Oben-Achsen der Kamera
    const forward = vNorm(vSub(v3(targetLookAt.x, targetLookAt.y, targetLookAt.z), camera.position));
    const worldUp = v3(0, 1, 0);
    const right = vNorm(vCross(forward, worldUp));
    const up = vNorm(vCross(right, forward));

    const panFactor = PAN_SPEED * spherical.radius;
    targetLookAt.x += (right.x * -deltaX + up.x * deltaY) * panFactor;
    targetLookAt.y += (right.y * -deltaX + up.y * deltaY) * panFactor;
    targetLookAt.z += (right.z * -deltaX + up.z * deltaY) * panFactor;
  }

  previousMousePosition = { x: event.clientX, y: event.clientY };
}

function onMouseUp() {
  isDragging = false;
  isPanning = false;
}

function onWheel(event) {
  if (!enabled || !camera) return;
  event.preventDefault();
  zoomVelocity += event.deltaY * ZOOM_SPEED;
}

// Touch-Handler
function onTouchStart(event) {
  if (!enabled || !camera) return;
  if (event.touches.length === 1) {
    isDragging = true;
    previousMousePosition = { x: event.touches[0].clientX, y: event.touches[0].clientY };
    velocity = { x: 0, y: 0 };
  } else if (event.touches.length === 2) {
    isPanning = true;
    const dx = event.touches[0].clientX - event.touches[1].clientX;
    const dy = event.touches[0].clientY - event.touches[1].clientY;
    touchStartDist = Math.sqrt(dx * dx + dy * dy);
    touchStartCenter = {
      x: (event.touches[0].clientX + event.touches[1].clientX) / 2,
      y: (event.touches[0].clientY + event.touches[1].clientY) / 2
    };
    zoomVelocity = 0;
  }
}

function onTouchMove(event) {
  if (!enabled || !camera) return;
  event.preventDefault();

  if (event.touches.length === 1 && isDragging) {
    const deltaX = event.touches[0].clientX - previousMousePosition.x;
    const deltaY = event.touches[0].clientY - previousMousePosition.y;
    spherical.theta -= deltaX * ROTATION_SPEED;
    spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi - deltaY * ROTATION_SPEED));
    velocity = { x: -deltaX * ROTATION_SPEED, y: -deltaY * ROTATION_SPEED };
    previousMousePosition = { x: event.touches[0].clientX, y: event.touches[0].clientY };
  } else if (event.touches.length === 2 && isPanning) {
    const dx = event.touches[0].clientX - event.touches[1].clientX;
    const dy = event.touches[0].clientY - event.touches[1].clientY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const deltaDist = touchStartDist - dist;
    zoomVelocity += deltaDist * ZOOM_SPEED * 0.5;
    touchStartDist = dist;

    const centerX = (event.touches[0].clientX + event.touches[1].clientX) / 2;
    const centerY = (event.touches[0].clientY + event.touches[1].clientY) / 2;
    const deltaX = centerX - touchStartCenter.x;
    const deltaY = centerY - touchStartCenter.y;

    // Screen-Space Panning für Touch
    const forward = vNorm(vSub(v3(targetLookAt.x, targetLookAt.y, targetLookAt.z), camera.position));
    const worldUp = v3(0, 1, 0);
    const right = vNorm(vCross(forward, worldUp));
    const up = vNorm(vCross(right, forward));

    const panFactor = PAN_SPEED * spherical.radius;
    targetLookAt.x += (right.x * -deltaX + up.x * deltaY) * panFactor;
    targetLookAt.y += (right.y * -deltaX + up.y * deltaY) * panFactor;
    targetLookAt.z += (right.z * -deltaX + up.z * deltaY) * panFactor;

    touchStartCenter = { x: centerX, y: centerY };
  }
}

function onTouchEnd() {
  isDragging = false;
  isPanning = false;
}

function update(deltaTime) {
  if (!enabled || !camera || typeof window === 'undefined') return;

  // 1. Delta-Time-Capping: Verhindert Inertia-Explosion bei Tab-Wechseln (max 100ms)
  const clampedDt = Math.min(deltaTime || 16.67, 100);
  const dtFactor = clampedDt / 16.67;

  const effectiveDamping = Math.pow(DAMPING, dtFactor);
  const effectiveZoomDamping = Math.pow(ZOOM_DAMPING, dtFactor);

  // 2. Inertia anwenden
  spherical.theta += velocity.x * dtFactor;
  spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi + velocity.y * dtFactor));
  velocity.x *= effectiveDamping;
  velocity.y *= effectiveDamping;

  spherical.radius += zoomVelocity * dtFactor;
  spherical.radius = Math.max(2, spherical.radius); // Minimaler Zoom-Abstand
  zoomVelocity *= effectiveZoomDamping;

  // 3. Kamera-Position basierend auf sphärischen Koordinaten und Ziel berechnen
  const x = targetLookAt.x + spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
  const y = targetLookAt.y + spherical.radius * Math.cos(spherical.phi);
  const z = targetLookAt.z + spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);

  if (currentMode === 'top-down') {
    camera.position.set(targetLookAt.x, targetLookAt.y + spherical.radius, targetLookAt.z);
    camera.lookAt(targetLookAt.x, targetLookAt.y, targetLookAt.z);
  } else {
    // 'orbit' und 'first-person'
    camera.position.set(x, y, z);
    camera.lookAt(targetLookAt.x, targetLookAt.y, targetLookAt.z);
  }
}

function setMode(mode) {
  if (!['orbit', 'top-down', 'first-person'].includes(mode)) return;
  currentMode = mode;

  if (mode === 'top-down') {
    spherical.phi = 0.1; // Fast senkrecht von oben
  } else if (mode === 'orbit') {
    spherical.phi = Math.PI / 2; // Äquatoriale Ansicht
  }
}

function focusBody(target, durationMs = 1000) {
  if (typeof window === 'undefined' || !camera) return;

  let endTarget = { x: 0, y: 0, z: 0 };

  // Flexible Zielauflösung
  if (typeof target === 'string') {
    const body = (window.LLP && window.LLP.bodies && window.LLP.bodies[target]) ? window.LLP.bodies[target].mesh : null;
    if (body && body.position) {
      endTarget = { x: body.position.x, y: body.position.y, z: body.position.z };
    }
  } else if (target && target.position) {
    endTarget = { x: target.position.x, y: target.position.y, z: target.position.z };
  } else if (target && typeof target.x === 'number') {
    endTarget = { x: target.x, y: target.y, z: target.z };
  }

  // 4. Robuster Offset: Klammerung verhindert extremes Wegfliegen aus großen Zoom-Stufen
  const safeRadius = Math.min(Math.max(20, spherical.radius), 200);
  const endPos = {
    x: endTarget.x + safeRadius * 0.5,
    y: endTarget.y + safeRadius * 0.8,
    z: endTarget.z + safeRadius * 0.5
  };

  const startPos = { x: camera.position.x, y: camera.position.y, z: camera.position.z };
  const startTarget = { x: targetLookAt.x, y: targetLookAt.y, z: targetLookAt.z };

  if (typeof tweenCamera === 'function') {
    tweenCamera(camera, startPos, endPos, startTarget, endTarget, durationMs, () => {
      targetLookAt = endTarget;
      const dx = camera.position.x - targetLookAt.x;
      const dy = camera.position.y - targetLookAt.y;
      const dz = camera.position.z - targetLookAt.z;
      spherical.radius = Math.sqrt(dx*dx + dy*dy + dz*dz);
    });
  } else {
    // Fallback
    camera.position.set(endPos.x, endPos.y, endPos.z);
    camera.lookAt(endTarget.x, endTarget.y, endTarget.z);
    targetLookAt = endTarget;
  }
}

function getCamera() {
  return camera;
}

export { enable, disable, focusBody, setMode, getCamera, update };
